import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Download, i as PenTool, o as Copy, r as ShieldCheck, s as Check, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DVcMaOo8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TEXT_INTENT = /\b(typography|lettering|watermark|caption|headline|slogan|alphabet|inscription|font|logo|words)\b|["“][^"”]{2,}["”]|\b(text|that says|with the word|says)\b/i;
function promptRequestsText(prompt) {
	return TEXT_INTENT.test(prompt);
}
function clampHue(h) {
	const x = h % 360;
	return x < 0 ? x + 360 : x;
}
function colorName(r, g, b) {
	const max = Math.max(r, g, b);
	const min = Math.min(r, g, b);
	const l = (max + min) / 2 / 255;
	const d = max - min;
	const s = d === 0 ? 0 : d / 255 / (1 - Math.abs(2 * l - 1));
	if (l > .92) return "white";
	if (l < .08) return "black";
	if (s < .12) return l > .62 ? "gray" : "charcoal";
	let h = 0;
	if (d !== 0) {
		if (max === r) h = (g - b) / d * 60;
		else if (max === g) h = (b - r) / d * 60 + 120;
		else h = (r - g) / d * 60 + 240;
	}
	h = clampHue(h);
	if (l > .82 && s < .35) return "cream";
	if (h < 18 || h >= 348) return l < .35 ? "burgundy" : "red";
	if (h < 40) return l < .45 ? "brown" : "orange";
	if (h < 55) return s < .45 ? "beige" : "amber";
	if (h < 70) return "yellow";
	if (h < 95) return "lime";
	if (h < 150) return l < .28 ? "forest" : "green";
	if (h < 180) return "teal";
	if (h < 200) return "cyan";
	if (h < 250) return l < .32 ? "navy" : "blue";
	if (h < 290) return "indigo";
	if (h < 330) return "purple";
	return "pink";
}
function median(values) {
	const copy = Array.from(values).sort((a, b) => a - b);
	const mid = Math.floor(copy.length / 2);
	return copy.length % 2 ? copy[mid] : (copy[mid - 1] + copy[mid]) / 2;
}
function detectText(data) {
	const { width, height, data: px } = data;
	const cols = 96;
	const rows = 96;
	const stepX = width / cols;
	const stepY = height / rows;
	const rowTrans = new Float32Array(rows);
	const lum = (x, y) => {
		const ix = Math.min(width - 1, Math.max(0, Math.round(x)));
		const i = (Math.min(height - 1, Math.max(0, Math.round(y))) * width + ix) * 4;
		return px[i] * .299 + px[i + 1] * .587 + px[i + 2] * .114;
	};
	for (let y = 0; y < rows; y++) {
		let trans = 0;
		let prevEdge = false;
		const py = (y + .5) * stepY;
		for (let x = 0; x < 95; x++) {
			const edge = Math.abs(lum((x + 1.5) * stepX, py) - lum((x + .5) * stepX, py)) > 48;
			if (edge && !prevEdge) trans += 1;
			prevEdge = edge;
		}
		rowTrans[y] = trans;
	}
	const mid = median(rowTrans);
	let bands = 0;
	let y = 1;
	while (y < 95) {
		if (!(rowTrans[y] >= 7 && rowTrans[y] <= 26 && rowTrans[y] > mid * 2)) {
			y += 1;
			continue;
		}
		let end = y;
		while (end < 95 && rowTrans[end] >= 6 && rowTrans[end] <= 28) end += 1;
		const heightRows = end - y;
		if (heightRows >= 2 && heightRows <= 6) {
			let sum = 0;
			for (let i = y; i < end; i++) sum += rowTrans[i];
			const avg = sum / heightRows;
			const above = rowTrans[Math.max(0, y - 2)];
			const below = rowTrans[Math.min(95, end + 1)];
			if (avg > above * 1.8 && avg > below * 1.8) bands += 1;
		}
		y = Math.max(end, y + 1);
	}
	const confidence = Math.min(1, bands / 4);
	return {
		hasText: bands >= 3,
		confidence
	};
}
function analyzeImage(data) {
	const { width, height, data: px } = data;
	const votes = /* @__PURE__ */ new Map();
	let lumSum = 0;
	let satSum = 0;
	let samples = 0;
	const quadLum = [
		[],
		[],
		[],
		[]
	];
	const step = 8;
	for (let y = 0; y < height; y += step) for (let x = 0; x < width; x += step) {
		const i = (y * width + x) * 4;
		const r = px[i];
		const g = px[i + 1];
		const b = px[i + 2];
		const lum = (r * .299 + g * .587 + b * .114) / 255;
		const max = Math.max(r, g, b) / 255;
		const min = Math.min(r, g, b) / 255;
		const sat = max === 0 ? 0 : (max - min) / max;
		lumSum += lum;
		satSum += sat;
		samples += 1;
		const name = colorName(r, g, b);
		if (name) votes.set(name, (votes.get(name) ?? 0) + 1);
		quadLum[(x < width / 2 ? 0 : 1) + (y < height / 2 ? 0 : 2)].push(lum);
	}
	const colors = [...votes.entries()].sort((a, b) => b[1] - a[1]).filter(([, count]) => count / samples > .08).slice(0, 3).map(([name]) => name);
	const meanLum = lumSum / Math.max(1, samples);
	const meanSat = satSum / Math.max(1, samples);
	const brightness = meanLum > .68 ? "bright" : meanLum < .32 ? "dark" : "balanced";
	const saturation = meanSat > .42 ? "vivid" : meanSat < .16 ? "muted" : "natural";
	let hasCopySpace = false;
	for (const values of quadLum) {
		if (values.length < 8) continue;
		const mean = values.reduce((s, v) => s + v, 0) / values.length;
		const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length;
		if (Math.sqrt(variance) < .07 && (mean > .72 || mean < .16)) hasCopySpace = true;
	}
	const text = detectText(data);
	return {
		colors,
		hasCopySpace,
		brightness,
		saturation,
		hasText: text.hasText,
		textConfidence: text.confidence
	};
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var generateStockImage = createServerFn({ method: "POST" }).validator((input) => {
	const data = input;
	const prompt = typeof data.prompt === "string" ? data.prompt.trim() : "";
	const mode = data.mode === "vector" ? "vector" : "photo";
	if (prompt.length < 3 || prompt.length > 500) throw new Error("Describe the image in 3–500 characters.");
	return {
		prompt,
		mode
	};
}).handler(createSsrRpc("526a365a74c12ecb54263fe08d2ea8ef8152ec1b6745a82bccae7fed570ff2a3"));
/** Read or write the JFIF density so a canvas JPEG carries a real 300 DPI tag. */
function markerLength(bytes, offset) {
	return bytes[offset + 2] << 8 | bytes[offset + 3];
}
function isStandalone(marker) {
	return marker === 216 || marker === 217 || marker === 1 || marker >= 208 && marker <= 215;
}
function findJfif(bytes) {
	if (bytes.length < 4 || bytes[0] !== 255 || bytes[1] !== 216) return -1;
	let offset = 2;
	while (offset + 4 < bytes.length) {
		if (bytes[offset] !== 255) return -1;
		const marker = bytes[offset + 1];
		if (isStandalone(marker)) {
			offset += 2;
			continue;
		}
		const len = markerLength(bytes, offset);
		if (len < 2 || offset + 2 + len > bytes.length) return -1;
		if (marker === 224 && len >= 16) {
			if (String.fromCharCode(bytes[offset + 4], bytes[offset + 5], bytes[offset + 6], bytes[offset + 7], bytes[offset + 8]) === "JFIF\0") return offset;
		}
		if (marker === 218) return -1;
		offset += 2 + len;
	}
	return -1;
}
function readJpegDpi(bytes) {
	const hit = findJfif(bytes);
	if (hit < 0) return null;
	if (bytes[hit + 11] !== 1) return null;
	return bytes[hit + 12] << 8 | bytes[hit + 13];
}
function hash(text) {
	let h = 2166136261;
	for (let i = 0; i < text.length; i++) {
		h ^= text.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function mulberry32(seed) {
	let a = seed || 1;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
var PALETTES = [
	[
		"#1c1915",
		"#d84a2f",
		"#f3efe6",
		"#e7d7b8",
		"#6d675e"
	],
	[
		"#143028",
		"#d84a2f",
		"#f6f1e8",
		"#efc56b",
		"#2f6f62"
	],
	[
		"#1d2433",
		"#e7e1d4",
		"#d84a2f",
		"#8aa0b8",
		"#faf7f2"
	],
	[
		"#3d2914",
		"#f0d2a0",
		"#d84a2f",
		"#6e8b74",
		"#f7f1e6"
	]
];
function paintLocalComp(prompt, mode) {
	const canvas = document.createElement("canvas");
	canvas.width = 1024;
	canvas.height = 1024;
	const ctx = canvas.getContext("2d");
	if (!ctx) return canvas;
	const rand = mulberry32(hash(`${mode}:${prompt}`));
	const palette = PALETTES[Math.floor(rand() * PALETTES.length)];
	const gradient = ctx.createLinearGradient(0, 0, 1024, 1024);
	gradient.addColorStop(0, palette[3]);
	gradient.addColorStop(1, palette[1] === "#d84a2f" ? palette[4] : palette[1]);
	ctx.fillStyle = gradient;
	ctx.fillRect(0, 0, 1024, 1024);
	if (mode === "vector") {
		ctx.fillStyle = palette[2];
		ctx.beginPath();
		ctx.arc(720, 280, 180, 0, Math.PI * 2);
		ctx.fill();
		ctx.fillStyle = palette[0];
		ctx.fillRect(120, 620, 520, 220);
		ctx.fillStyle = palette[1];
		ctx.beginPath();
		ctx.moveTo(180, 620);
		ctx.lineTo(420, 360);
		ctx.lineTo(660, 620);
		ctx.closePath();
		ctx.fill();
		for (let i = 0; i < 5; i++) {
			ctx.fillStyle = palette[i % palette.length];
			const x = 140 + rand() * 740;
			const y = 140 + rand() * 500;
			const s = 70 + rand() * 140;
			ctx.fillRect(x, y, s, s * (.45 + rand() * .5));
		}
		return canvas;
	}
	const glow = ctx.createRadialGradient(360, 280, 40, 420, 360, 640);
	glow.addColorStop(0, "rgba(255,248,236,0.85)");
	glow.addColorStop(1, "rgba(255,248,236,0)");
	ctx.fillStyle = glow;
	ctx.fillRect(0, 0, 1024, 1024);
	for (let i = 0; i < 14; i++) {
		ctx.fillStyle = palette[i % palette.length];
		ctx.globalAlpha = .18 + rand() * .28;
		ctx.beginPath();
		ctx.ellipse(rand() * 1024, rand() * 1024, 80 + rand() * 220, 60 + rand() * 180, rand() * Math.PI, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
	ctx.fillStyle = palette[0];
	ctx.globalAlpha = .55;
	ctx.fillRect(0, 700, 1024, 324);
	ctx.globalAlpha = 1;
	ctx.fillStyle = palette[2];
	ctx.beginPath();
	ctx.ellipse(512, 760, 220, 70, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = palette[1];
	ctx.beginPath();
	ctx.arc(512, 560, 120, 0, Math.PI * 2);
	ctx.fill();
	return canvas;
}
var STOP = /* @__PURE__ */ new Set([
	"a",
	"an",
	"the",
	"and",
	"or",
	"with",
	"of",
	"on",
	"in",
	"to",
	"for",
	"from",
	"by",
	"at",
	"into",
	"over",
	"near",
	"under",
	"its",
	"this",
	"that",
	"very",
	"highly",
	"beautiful",
	"stunning",
	"amazing",
	"image",
	"photo",
	"picture",
	"background",
	"wallpaper",
	"stock",
	"shutterstock",
	"getty",
	"jpg",
	"jpeg",
	"png",
	"eps",
	"render",
	"rendered",
	"style",
	"scene",
	"shot",
	"looking",
	"featuring",
	"showing",
	"without",
	"no",
	"not",
	"using",
	"use",
	"made",
	"make",
	"just",
	"really",
	"simple"
]);
var BANNED = /* @__PURE__ */ new Set([
	"text",
	"watermark",
	"logo",
	"signature",
	"typography",
	"lettering",
	"caption",
	"4k",
	"8k",
	"hd",
	"uhd",
	"high resolution",
	"high quality",
	"best",
	"awesome",
	"shutterstock",
	"stockgen",
	"getty",
	"istock",
	"adobe"
]);
var RELATED = {
	coffee: [
		"espresso",
		"latte",
		"cafe",
		"beverage",
		"mug",
		"caffeine",
		"brew",
		"barista",
		"saucer",
		"hot drink"
	],
	cup: [
		"mug",
		"ceramic",
		"drink",
		"saucer",
		"tableware"
	],
	tea: [
		"teapot",
		"herbal",
		"beverage",
		"cup",
		"infusion"
	],
	kitchen: [
		"cooking",
		"counter",
		"culinary",
		"home",
		"interior",
		"utensil"
	],
	lemon: [
		"citrus",
		"fruit",
		"yellow",
		"zest",
		"fresh"
	],
	fruit: [
		"fresh",
		"produce",
		"healthy",
		"food",
		"organic"
	],
	food: [
		"cuisine",
		"meal",
		"gourmet",
		"ingredient",
		"delicious"
	],
	bread: [
		"bakery",
		"loaf",
		"wheat",
		"breakfast",
		"baked"
	],
	desk: [
		"workspace",
		"table",
		"office",
		"stationery",
		"work"
	],
	laptop: [
		"computer",
		"notebook",
		"technology",
		"keyboard",
		"remote work"
	],
	workspace: [
		"home office",
		"desk",
		"productivity",
		"remote work",
		"office"
	],
	office: [
		"business",
		"corporate",
		"workplace",
		"professional",
		"desk"
	],
	plant: [
		"houseplant",
		"foliage",
		"greenery",
		"botanical",
		"leaf"
	],
	monstera: [
		"houseplant",
		"tropical",
		"leaf",
		"foliage",
		"botanical"
	],
	flower: [
		"floral",
		"bloom",
		"petal",
		"botanical",
		"garden"
	],
	garden: [
		"outdoor",
		"botanical",
		"plant",
		"yard",
		"nature"
	],
	tree: [
		"forest",
		"woodland",
		"branch",
		"foliage",
		"nature"
	],
	forest: [
		"woodland",
		"trees",
		"nature",
		"wilderness",
		"trail"
	],
	mountain: [
		"peak",
		"landscape",
		"alpine",
		"hiking",
		"summit"
	],
	ocean: [
		"sea",
		"water",
		"wave",
		"marine",
		"seascape"
	],
	sea: [
		"ocean",
		"water",
		"coast",
		"marine",
		"horizon"
	],
	beach: [
		"shore",
		"sand",
		"coast",
		"seaside",
		"summer"
	],
	coast: [
		"coastline",
		"shore",
		"seascape",
		"cliff",
		"ocean"
	],
	coastline: [
		"coast",
		"shore",
		"aerial",
		"seascape",
		"water"
	],
	wave: [
		"water",
		"surf",
		"ocean",
		"ripple",
		"sea"
	],
	road: [
		"highway",
		"journey",
		"asphalt",
		"travel",
		"path"
	],
	street: [
		"urban",
		"city",
		"sidewalk",
		"downtown",
		"road"
	],
	city: [
		"urban",
		"downtown",
		"skyline",
		"metropolitan",
		"architecture"
	],
	courier: [
		"delivery",
		"parcel",
		"messenger",
		"package",
		"shipping"
	],
	bicycle: [
		"bike",
		"cycling",
		"cyclist",
		"commute",
		"two wheeler"
	],
	bike: [
		"bicycle",
		"cycling",
		"rider",
		"commute"
	],
	delivery: [
		"parcel",
		"shipping",
		"package",
		"courier",
		"logistics"
	],
	car: [
		"automobile",
		"vehicle",
		"driving",
		"transport",
		"road"
	],
	kitchenisland: [
		"kitchen",
		"island",
		"counter",
		"interior"
	],
	bowl: [
		"ceramic",
		"tableware",
		"dish",
		"kitchen"
	],
	window: [
		"daylight",
		"glass",
		"interior",
		"sunlight",
		"view"
	],
	sunlight: [
		"daylight",
		"sunshine",
		"natural light",
		"sunny",
		"morning"
	],
	morning: [
		"sunrise",
		"dawn",
		"daylight",
		"breakfast",
		"early"
	],
	linen: [
		"fabric",
		"textile",
		"cloth",
		"tablecloth",
		"texture"
	],
	ceramic: [
		"pottery",
		"stoneware",
		"handmade",
		"tableware"
	],
	abstract: [
		"geometric",
		"shape",
		"modern art",
		"pattern",
		"composition"
	],
	pattern: [
		"repeat",
		"texture",
		"motif",
		"decorative",
		"surface"
	],
	paper: [
		"stationery",
		"sheet",
		"craft",
		"texture",
		"layered"
	],
	portrait: [
		"person",
		"face",
		"headshot",
		"people",
		"human"
	],
	woman: [
		"female",
		"person",
		"people",
		"adult",
		"human"
	],
	man: [
		"male",
		"person",
		"people",
		"adult",
		"human"
	],
	hands: [
		"hand",
		"gesture",
		"fingers",
		"human",
		"closeup"
	],
	dog: [
		"puppy",
		"canine",
		"pet",
		"animal",
		"companion"
	],
	cat: [
		"kitten",
		"feline",
		"pet",
		"animal",
		"companion"
	],
	bird: [
		"avian",
		"wildlife",
		"feather",
		"animal",
		"wing"
	],
	fitness: [
		"exercise",
		"workout",
		"health",
		"active",
		"training"
	],
	yoga: [
		"wellness",
		"stretch",
		"mindfulness",
		"fitness",
		"pose"
	],
	medical: [
		"healthcare",
		"clinic",
		"health",
		"medicine",
		"hospital"
	],
	doctor: [
		"physician",
		"healthcare",
		"medical",
		"clinic",
		"professional"
	],
	phone: [
		"smartphone",
		"mobile",
		"device",
		"technology",
		"screen"
	],
	technology: [
		"digital",
		"innovation",
		"device",
		"modern",
		"tech"
	],
	fashion: [
		"style",
		"clothing",
		"apparel",
		"trend",
		"wardrobe"
	],
	shoe: [
		"footwear",
		"sneaker",
		"leather",
		"fashion"
	],
	interior: [
		"indoor",
		"room",
		"decor",
		"design",
		"home"
	],
	home: [
		"house",
		"domestic",
		"indoor",
		"living",
		"interior"
	],
	sofa: [
		"couch",
		"living room",
		"furniture",
		"interior",
		"seating"
	],
	table: [
		"furniture",
		"surface",
		"dining",
		"wood"
	],
	wood: [
		"wooden",
		"timber",
		"grain",
		"oak",
		"natural"
	],
	oak: [
		"wood",
		"timber",
		"furniture",
		"grain"
	],
	sky: [
		"clouds",
		"atmosphere",
		"horizon",
		"blue sky",
		"air"
	],
	sunset: [
		"dusk",
		"evening",
		"golden hour",
		"sky",
		"twilight"
	],
	island: [
		"tropical",
		"travel",
		"destination",
		"coast",
		"vacation"
	],
	travel: [
		"journey",
		"destination",
		"tourism",
		"trip",
		"adventure"
	],
	business: [
		"corporate",
		"professional",
		"commerce",
		"enterprise",
		"work"
	],
	meeting: [
		"conference",
		"team",
		"collaboration",
		"office",
		"discussion"
	],
	chart: [
		"graph",
		"analytics",
		"data",
		"statistics",
		"growth"
	],
	data: [
		"analytics",
		"information",
		"digital",
		"statistics"
	],
	robot: [
		"automation",
		"machine",
		"technology",
		"future",
		"android"
	],
	abstractpaper: [
		"paper",
		"layered",
		"craft",
		"texture"
	]
};
var CATEGORY_CUES = {
	food: [
		"coffee",
		"cup",
		"tea",
		"kitchen",
		"lemon",
		"bread",
		"fruit",
		"food",
		"meal",
		"cafe",
		"wine",
		"cake",
		"bowl",
		"drink"
	],
	nature: [
		"forest",
		"mountain",
		"ocean",
		"sea",
		"tree",
		"flower",
		"leaf",
		"plant",
		"sky",
		"beach",
		"water",
		"sunset",
		"river",
		"garden",
		"monstera"
	],
	travel: [
		"coast",
		"coastline",
		"road",
		"city",
		"street",
		"travel",
		"island",
		"hotel",
		"landmark",
		"skyline"
	],
	business: [
		"office",
		"desk",
		"laptop",
		"meeting",
		"workspace",
		"business",
		"chart",
		"team"
	],
	home: [
		"interior",
		"sofa",
		"bedroom",
		"kitchen",
		"furniture",
		"home",
		"room",
		"table",
		"linen"
	],
	animal: [
		"dog",
		"cat",
		"bird",
		"horse",
		"wildlife",
		"pet",
		"animal",
		"fish"
	],
	people: [
		"person",
		"woman",
		"man",
		"portrait",
		"face",
		"hands",
		"family",
		"child"
	],
	tech: [
		"phone",
		"computer",
		"technology",
		"data",
		"screen",
		"device",
		"robot",
		"laptop"
	],
	transport: [
		"car",
		"bicycle",
		"bike",
		"courier",
		"delivery",
		"train",
		"plane",
		"vehicle"
	],
	wellness: [
		"medical",
		"health",
		"doctor",
		"hospital",
		"yoga",
		"fitness",
		"wellness"
	],
	fashion: [
		"fashion",
		"clothes",
		"dress",
		"shoe",
		"fabric",
		"style"
	],
	abstract: [
		"abstract",
		"pattern",
		"shape",
		"geometric",
		"texture",
		"paper",
		"gradient"
	]
};
var CATEGORY_TAIL = {
	food: [
		"ingredient",
		"recipe",
		"fresh food",
		"tabletop",
		"still life",
		"culinary",
		"breakfast table",
		"homemade",
		"snack",
		"refreshment",
		"dining",
		"aroma",
		"kitchenware",
		"served",
		"tasty"
	],
	nature: [
		"landscape",
		"outdoors",
		"scenery",
		"natural",
		"environment",
		"wilderness",
		"organic",
		"ecosystem",
		"earth",
		"flora",
		"horizon line",
		"open air",
		"peaceful",
		"scenic",
		"conservation"
	],
	travel: [
		"destination",
		"getaway",
		"tourism",
		"journey",
		"vacation",
		"explore",
		"wanderlust",
		"scenic route",
		"trip",
		"adventure",
		"landmark view",
		"holiday",
		"abroad",
		"itinerary",
		"discovery"
	],
	business: [
		"professional",
		"corporate",
		"workplace",
		"career",
		"startup",
		"strategy",
		"productivity",
		"entrepreneur",
		"commerce",
		"success",
		"planning",
		"colleague",
		"briefcase",
		"deadline",
		"growth"
	],
	home: [
		"interior design",
		"decor",
		"domestic",
		"cozy",
		"living space",
		"household",
		"room interior",
		"furniture design",
		"comfortable",
		"homestyle",
		"indoor living",
		"styling",
		"residential",
		"nest",
		"ambiance"
	],
	animal: [
		"wildlife",
		"pet care",
		"animal portrait",
		"fur",
		"companion",
		"nature animal",
		"creature",
		"fauna",
		"loyal",
		"outdoors animal",
		"mammal",
		"whisker",
		"paw",
		"habitat",
		"zoology"
	],
	people: [
		"lifestyle",
		"human",
		"adult",
		"candid",
		"everyday life",
		"person portrait",
		"expression",
		"real people",
		"community",
		"individual",
		"character",
		"gesture",
		"skin",
		"looking away",
		"generation"
	],
	tech: [
		"digital",
		"innovation",
		"device",
		"modern technology",
		"electronics",
		"screen glow",
		"connected",
		"gadget",
		"software concept",
		"future",
		"smart device",
		"network",
		"interface",
		"hardware",
		"online"
	],
	transport: [
		"transportation",
		"commute",
		"mobility",
		"vehicle",
		"traffic",
		"logistics",
		"urban travel",
		"on the move",
		"transit",
		"shipping",
		"rider",
		"route",
		"speed",
		"cargo",
		"street travel"
	],
	wellness: [
		"healthy",
		"wellbeing",
		"self care",
		"balance",
		"clinic",
		"healthcare",
		"mind and body",
		"routine",
		"calm",
		"recovery",
		"active life",
		"vitality",
		"treatment",
		"prevention",
		"lifestyle health"
	],
	fashion: [
		"apparel",
		"outfit",
		"trend",
		"wardrobe",
		"textile",
		"clothing detail",
		"runway",
		"garment",
		"accessory",
		"tailoring",
		"seasonal style",
		"lookbook",
		"couture",
		"fabric texture",
		"styling"
	],
	abstract: [
		"modern art",
		"graphic",
		"shape study",
		"creative",
		"art print",
		"minimal art",
		"color field",
		"design element",
		"contemporary",
		"visual art",
		"form",
		"art background",
		"studio art",
		"composition study",
		"fine art"
	],
	general: [
		"still life",
		"detail",
		"everyday",
		"concept",
		"scene",
		"subject",
		"arrangement",
		"setting",
		"atmosphere",
		"visual",
		"object",
		"surface",
		"environment",
		"theme",
		"study"
	]
};
function sanitizeKeyword(raw) {
	return raw.toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9\s-]/g, " ").replace(/\s+/g, " ").trim();
}
function significantTokens(prompt) {
	return sanitizeKeyword(prompt).split(" ").filter((word) => word.length > 2 && !STOP.has(word) && !/^\d+$/.test(word));
}
function bigrams(tokens) {
	const weak = /* @__PURE__ */ new Set([
		"soft",
		"late",
		"empty",
		"simple",
		"modern",
		"clean",
		"flat",
		"side",
		"above",
		"behind",
		"riding",
		"winding",
		"afternoon",
		"close-up",
		"open",
		"small",
		"large"
	]);
	const phrases = [];
	for (let i = 0; i < tokens.length - 1; i++) {
		if (weak.has(tokens[i]) || weak.has(tokens[i + 1])) continue;
		if (STOP.has(tokens[i]) || STOP.has(tokens[i + 1])) continue;
		phrases.push(`${tokens[i]} ${tokens[i + 1]}`);
	}
	return phrases;
}
function detectCategory(words) {
	const blob = words.join(" ");
	let best = "general";
	let score = 0;
	for (const [category, cues] of Object.entries(CATEGORY_CUES)) {
		const hits = cues.reduce((n, cue) => n + (blob.includes(cue) ? 1 : 0), 0);
		if (hits > score) {
			score = hits;
			best = category;
		}
	}
	return best;
}
function cleanTitle(prompt, mode, colors) {
	const cleaned = prompt.replace(/\s+/g, " ").replace(/[^\w\s,'’-]/g, "").trim().replace(/[.!?]+$/g, "");
	const base = cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
	let title = base;
	if (mode === "vector" && !/\bvector\b|\billustration\b/i.test(title)) title = `Flat vector illustration of ${base.charAt(0).toLowerCase()}${base.slice(1)}`;
	else if (mode === "photo" && title.length < 48 && colors[0]) title = `${base} in ${colors[0]} tones`;
	if (title.length > 180) title = title.slice(0, 177).replace(/\s+\S*$/, "");
	return title;
}
function slugKeyword(input) {
	return sanitizeKeyword(input).replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 40) || "stock";
}
function fileBase(keyword) {
	return `stockgen_ai_5000px_${slugKeyword(keyword)}`;
}
function buildStockMeta(input) {
	const tokens = significantTokens(input.prompt);
	const primary = sanitizeKeyword(input.primary) || tokens[0] || "stock";
	const ordered = [];
	const seen = /* @__PURE__ */ new Set();
	const add = (raw) => {
		const keyword = sanitizeKeyword(raw);
		if (!keyword || keyword.length < 2 || keyword.length > 32) return;
		if (seen.has(keyword) || STOP.has(keyword) || BANNED.has(keyword)) return;
		if ([...seen].some((existing) => existing.endsWith("s") === false && keyword === `${existing}s`)) return;
		const parts = keyword.split(" ");
		if (new Set(parts).size !== parts.length) return;
		seen.add(keyword);
		ordered.push(keyword);
	};
	add(primary);
	for (const token of tokens) add(token);
	for (const rel of RELATED[primary] ?? []) add(rel);
	for (const token of tokens) for (const rel of RELATED[token] ?? []) add(rel);
	for (const color of input.colors) add(color);
	if (input.hasCopySpace) add("copy space");
	if (input.brightness === "bright") {
		add("bright");
		add("high key");
		add("soft light");
	} else if (input.brightness === "dark") {
		add("dark");
		add("low key");
		add("moody");
	} else add("natural light");
	if (input.saturation === "vivid") add("vivid color");
	if (input.saturation === "muted") add("muted color");
	for (const phrase of bigrams(tokens)) add(phrase);
	const category = detectCategory([
		primary,
		...tokens,
		...ordered
	]);
	for (const tail of CATEGORY_TAIL[category] ?? CATEGORY_TAIL.general) add(tail);
	if (input.mode === "vector") for (const term of [
		"vector illustration",
		"flat design",
		"geometric",
		"solid color",
		"clean shape",
		"graphic illustration"
	]) add(term);
	else for (const term of [
		"realistic",
		"photorealistic",
		"commercial",
		"lifestyle photography"
	]) add(term);
	const modifiers = input.mode === "vector" ? [
		"flat",
		"simple",
		"geometric",
		"icon"
	] : [
		"close up",
		"detail",
		"natural",
		"commercial"
	];
	const subjects = [primary, ...tokens].slice(0, 6);
	for (const subject of subjects) {
		for (const modifier of modifiers) add(`${modifier} ${subject}`);
		for (const color of input.colors.slice(0, 2)) add(`${color} ${subject}`);
	}
	for (const token of tokens) for (const rel of RELATED[token] ?? []) add(rel);
	for (const tail of CATEGORY_TAIL.general) add(tail);
	for (const extra of [
		"square format",
		"centered subject",
		"clean backdrop",
		"editorial",
		"catalog",
		"advertising",
		"minimal",
		"modern",
		"detail shot",
		"studio setup"
	]) add(extra);
	const keywords = ordered.slice(0, 40);
	while (keywords.length < 40) {
		const filler = `concept ${keywords.length + 1}`;
		if (seen.has(filler)) break;
		seen.add(filler);
		keywords.push(filler);
	}
	return {
		title: cleanTitle(input.prompt, input.mode, input.colors),
		keywords
	};
}
function parseKeywordText(text) {
	const seen = /* @__PURE__ */ new Set();
	const list = [];
	for (const part of text.split(/[,|\n]/)) {
		const keyword = sanitizeKeyword(part);
		if (!keyword || seen.has(keyword)) continue;
		seen.add(keyword);
		list.push(keyword);
	}
	return list;
}
var SESSION_CAP = 8;
var SESSION_KEY = "stockgen-gens";
var PRESETS = [
	{
		label: "Cafe pour",
		mode: "photo",
		keyword: "coffee",
		prompt: "Close-up of a ceramic cup of coffee on linen with soft morning window light"
	},
	{
		label: "Coast road",
		mode: "photo",
		keyword: "coast",
		prompt: "Winding coastal road above turquoise water in late afternoon sun, empty of people"
	},
	{
		label: "Oak kitchen",
		mode: "photo",
		keyword: "kitchen",
		prompt: "Modern oak kitchen island with a ceramic bowl of lemons and soft side light"
	},
	{
		label: "Courier",
		mode: "vector",
		keyword: "courier",
		prompt: "Delivery courier riding a bicycle with a parcel and simple city shapes behind"
	},
	{
		label: "Desk plant",
		mode: "vector",
		keyword: "workspace",
		prompt: "Desk with a laptop, monstera plant, and coffee mug in flat geometric shapes"
	}
];
function formatMb(bytes) {
	return `${(bytes / 1048576).toFixed(2)} MB`;
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const anchor = document.createElement("a");
	anchor.href = url;
	anchor.download = filename;
	document.body.appendChild(anchor);
	anchor.click();
	anchor.remove();
	window.setTimeout(() => URL.revokeObjectURL(url), 2500);
}
function loadUsed() {
	try {
		return Number(sessionStorage.getItem(SESSION_KEY) || "0") || 0;
	} catch {
		return 0;
	}
}
function Studio() {
	const [mode, setMode] = (0, import_react.useState)("photo");
	const [prompt, setPrompt] = (0, import_react.useState)(PRESETS[0].prompt);
	const [primary, setPrimary] = (0, import_react.useState)(PRESETS[0].keyword);
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [status, setStatus] = (0, import_react.useState)("Engine idle");
	const [error, setError] = (0, import_react.useState)("");
	const [file, setFile] = (0, import_react.useState)(null);
	const [title, setTitle] = (0, import_react.useState)("");
	const [keywordText, setKeywordText] = (0, import_react.useState)("");
	const [trace, setTrace] = (0, import_react.useState)(null);
	const [copied, setCopied] = (0, import_react.useState)("");
	const [remaining, setRemaining] = (0, import_react.useState)(SESSION_CAP);
	const [split, setSplit] = (0, import_react.useState)(54);
	const frameRef = (0, import_react.useRef)(null);
	const [frameWidth, setFrameWidth] = (0, import_react.useState)(640);
	const masterRef = (0, import_react.useRef)(null);
	const urlsRef = (0, import_react.useRef)([]);
	(0, import_react.useEffect)(() => {
		setRemaining(Math.max(0, SESSION_CAP - loadUsed()));
	}, []);
	(0, import_react.useEffect)(() => {
		const el = frameRef.current;
		if (!el) return;
		const measure = () => setFrameWidth(el.clientWidth);
		measure();
		const observer = new ResizeObserver(measure);
		observer.observe(el);
		return () => observer.disconnect();
	}, [file]);
	(0, import_react.useEffect)(() => {
		return () => {
			for (const url of urlsRef.current) URL.revokeObjectURL(url);
		};
	}, []);
	const keywords = parseKeywordText(keywordText);
	const base = fileBase(primary || keywords[0] || "stock");
	const jpgName = `${base}.jpg`;
	const epsName = `${base}.eps`;
	const busy = phase === "generating" || phase === "upscaling" || phase === "tracing";
	async function copyText(key, value) {
		try {
			await navigator.clipboard.writeText(value);
			setCopied(key);
			window.setTimeout(() => setCopied((current) => current === key ? "" : current), 1400);
		} catch {
			setCopied("");
		}
	}
	function rememberUrl(url) {
		urlsRef.current.push(url);
	}
	async function upscaleMaster(source, width, height, sourceMode, sourcePrompt) {
		const master = document.createElement("canvas");
		master.width = 1024;
		master.height = 1024;
		const ctx = master.getContext("2d", { willReadFrequently: true });
		if (!ctx) throw new Error("Could not open a canvas.");
		ctx.imageSmoothingEnabled = true;
		ctx.imageSmoothingQuality = "high";
		const cover = Math.max(1024 / width, 1024 / height);
		const dw = width * cover;
		const dh = height * cover;
		ctx.drawImage(source, (1024 - dw) / 2, (1024 - dh) / 2, dw, dh);
		masterRef.current = master;
		const analysis = analyzeImage(ctx.getImageData(0, 0, 1024, 1024));
		const beforeUrl = master.toDataURL("image/jpeg", .92);
		const peek = document.createElement("canvas");
		peek.width = 220;
		peek.height = 220;
		const peekCtx = peek.getContext("2d");
		if (!peekCtx) throw new Error("Could not build the comparison crop.");
		peekCtx.imageSmoothingEnabled = false;
		const span = 220 * (1024 / 5e3);
		peekCtx.drawImage(master, 512 - span / 2, 512 - span / 2, span, span, 0, 0, 220, 220);
		const beforePeek = peek.toDataURL("image/jpeg", .92);
		setPhase("upscaling");
		setProgress(8);
		setStatus("Auto-upscale engine starting");
		const bitmap = await createImageBitmap(master);
		const worker = new Worker(new URL("../lib/upscale.worker.ts", import.meta.url), { type: "module" });
		try {
			const result = await new Promise((resolve, reject) => {
				worker.onmessage = (event) => {
					const data = event.data;
					if (data.type === "progress") {
						setProgress(data.pct ?? 0);
						setStatus(data.label ?? "Upscaling");
					} else if (data.type === "done" && data.jpeg && data.preview && data.peek) resolve({
						jpeg: data.jpeg,
						preview: data.preview,
						peek: data.peek,
						dpi: data.dpi ?? 0
					});
					else if (data.type === "error") reject(new Error(data.message || "Upscale failed."));
				};
				worker.onerror = () => reject(/* @__PURE__ */ new Error("The upscale engine stopped."));
				worker.postMessage({
					bitmap,
					mode: sourceMode
				}, [bitmap]);
			});
			const jpegBytes = new Uint8Array(result.jpeg);
			const dpi = readJpegDpi(jpegBytes) ?? result.dpi;
			const afterUrl = URL.createObjectURL(new Blob([result.preview], { type: "image/jpeg" }));
			const afterPeek = URL.createObjectURL(new Blob([result.peek], { type: "image/jpeg" }));
			rememberUrl(afterUrl);
			rememberUrl(afterPeek);
			const jpeg = new Blob([jpegBytes], { type: "image/jpeg" });
			const meta = buildStockMeta({
				prompt: sourcePrompt,
				mode: sourceMode,
				primary: primary.trim() || sourcePrompt,
				colors: analysis.colors,
				hasCopySpace: analysis.hasCopySpace,
				brightness: analysis.brightness,
				saturation: analysis.saturation
			});
			setTitle(meta.title);
			setKeywordText(meta.keywords.join(", "));
			setTrace(null);
			setFile({
				mode: sourceMode,
				prompt: sourcePrompt,
				width: 5e3,
				height: 5e3,
				dpi,
				bytes: jpegBytes.byteLength,
				beforeUrl,
				afterUrl,
				beforePeek,
				afterPeek,
				jpeg,
				analysis,
				textIntent: promptRequestsText(sourcePrompt)
			});
			setProgress(100);
			setStatus("5000 px locked · title and 40 keywords written");
			setPhase("ready");
		} finally {
			worker.terminate();
		}
	}
	async function onGenerate() {
		if (busy) return;
		setError("");
		if (loadUsed() >= SESSION_CAP) {
			setError("Live render limit reached for this session. Use a studio comp, or refresh later.");
			return;
		}
		setPhase("generating");
		setProgress(4);
		setStatus("Composing the 1024 master");
		try {
			const response = await generateStockImage({ data: {
				prompt,
				mode
			} });
			if (!response.ok) throw new Error(response.error);
			const used = loadUsed() + 1;
			sessionStorage.setItem(SESSION_KEY, String(used));
			setRemaining(Math.max(0, SESSION_CAP - used));
			const image = await loadHtmlImage(`data:${response.mime};base64,${response.base64}`);
			await upscaleMaster(image, image.naturalWidth, image.naturalHeight, mode, prompt);
		} catch (err) {
			setPhase(file ? "ready" : "idle");
			setError(err instanceof Error ? err.message : "Generation failed.");
		}
	}
	async function onComp() {
		if (busy) return;
		setError("");
		setPhase("generating");
		setStatus("Painting a local studio comp");
		setProgress(6);
		try {
			await upscaleMaster(paintLocalComp(prompt, mode), 1024, 1024, mode, prompt);
		} catch (err) {
			setPhase(file ? "ready" : "idle");
			setError(err instanceof Error ? err.message : "Studio comp failed.");
		}
	}
	async function onTrace() {
		const master = masterRef.current;
		if (!master || !file || file.mode !== "vector" || phase === "tracing") return;
		setPhase("tracing");
		setStatus("Tracing paths to Illustrator 10 EPS");
		setError("");
		try {
			const bitmap = await createImageBitmap(master);
			const worker = new Worker(new URL("../lib/trace.worker.ts", import.meta.url), { type: "module" });
			const traced = await new Promise((resolve, reject) => {
				worker.onmessage = (event) => {
					const data = event.data;
					if (data.type === "done" && data.eps && data.svg) resolve({
						eps: data.eps,
						svg: data.svg,
						paths: data.paths ?? 0
					});
					else if (data.type === "error") reject(new Error(data.message || "Trace failed."));
				};
				worker.onerror = () => reject(/* @__PURE__ */ new Error("Vector tracer stopped."));
				worker.postMessage({
					bitmap,
					title: epsName
				}, [bitmap]);
			});
			worker.terminate();
			const eps = new Blob([traced.eps], { type: "application/postscript" });
			const svgUrl = URL.createObjectURL(new Blob([traced.svg], { type: "image/svg+xml" }));
			rememberUrl(svgUrl);
			setTrace({
				eps,
				svgUrl,
				paths: traced.paths
			});
			setStatus(`Vector locked · ${traced.paths} paths`);
			setPhase("ready");
			downloadBlob(eps, epsName);
		} catch (err) {
			setPhase("ready");
			setError(err instanceof Error ? err.message : "Trace failed.");
		}
	}
	function rebuildMeta() {
		if (!file) return;
		const meta = buildStockMeta({
			prompt: file.prompt,
			mode: file.mode,
			primary,
			colors: file.analysis.colors,
			hasCopySpace: file.analysis.hasCopySpace,
			brightness: file.analysis.brightness,
			saturation: file.analysis.saturation
		});
		setTitle(meta.title);
		setKeywordText(meta.keywords.join(", "));
	}
	const noText = file ? !file.analysis.hasText && !file.textIntent : false;
	const pixelsOk = !!file && file.width > 4e3 && file.height > 4e3;
	const sizeOk = !!file && file.bytes > 4194304;
	const dpiOk = !!file && file.dpi === 300;
	const validatorPass = pixelsOk && sizeOk && dpiOk && noText;
	const inProfile = !!file && file.bytes >= 15728640 && file.bytes <= 20971520;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-line bg-paper",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-11 place-items-center bg-accent font-display text-xl text-accent-ink",
						children: "Sg"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-display text-3xl leading-none text-ink",
						children: ["StockGen ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-accent italic",
							children: "AI"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Contributor desk · auto-upscale to 5000 px"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted tabular-nums",
					children: [
						"Live renders left ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-ink",
							children: remaining
						}),
						" / ",
						SESSION_CAP
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-[22rem_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-line bg-paper p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-wide text-muted uppercase",
							children: "Auto-upscale engine"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-ink",
							children: "Every generate locks a 1024 master, then rebuilds it in the browser to 5000×5000, 300 DPI, JPEG quality 100%. Title and 40 Shutterstock keywords are written the moment the upscale finishes."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
							className: "mt-3 space-y-1 text-sm text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1 · Source 1024×1024" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2 · Canvas passes 2048 → 4096 → 5000" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3 · JFIF tag set to 300 DPI" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "4 · Metadata: title + 40 keywords" })
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-line bg-paper p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2",
							children: ["photo", "vector"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMode(item),
								className: `h-11 rounded-md border text-sm ${mode === item ? "border-ink bg-ink text-paper" : "border-line bg-bg text-ink"}`,
								children: item === "photo" ? "Photo" : "Vector"
							}, item))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-4 block text-sm text-muted",
							htmlFor: "prompt",
							children: "Prompt"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "prompt",
							value: prompt,
							onChange: (event) => setPrompt(event.target.value),
							rows: 5,
							maxLength: 500,
							className: "mt-1 w-full resize-none rounded-md border border-line bg-bg px-3 py-2 text-sm text-ink outline-none focus-visible:outline-2 focus-visible:outline-accent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "mt-3 block text-sm text-muted",
							htmlFor: "keyword",
							children: "Filename keyword"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "keyword",
							value: primary,
							onChange: (event) => setPrimary(event.target.value),
							className: "mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-sm text-ink outline-none focus-visible:outline-2 focus-visible:outline-accent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs break-all text-muted",
							children: jpgName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setMode(preset.mode);
									setPrompt(preset.prompt);
									setPrimary(preset.keyword);
								},
								className: "h-11 rounded-md border border-line bg-bg px-3 text-sm text-ink",
								children: preset.label
							}, preset.label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onGenerate,
							disabled: busy || prompt.trim().length < 3,
							className: "mt-4 h-11 w-full rounded-md bg-accent text-sm text-accent-ink disabled:opacity-50",
							children: phase === "generating" ? "Composing 1024…" : "Generate 1024 + auto-upscale"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onComp,
							disabled: busy || prompt.trim().length < 3,
							className: "mt-2 h-11 w-full rounded-md border border-line bg-bg text-sm text-ink disabled:opacity-50",
							children: "Studio comp · no model credit"
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-fail",
							children: error
						}) : null
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex min-w-0 flex-col gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-stage p-3 text-stage-fg sm:p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm tabular-nums text-stage-fg",
								children: busy ? `${progress}%` : file ? "Locked" : "Idle"
							})]
						}),
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-3 h-1 overflow-hidden rounded-full bg-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-accent",
								style: { width: `${Math.max(4, progress)}%` }
							})
						}) : null,
						file ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							ref: frameRef,
							className: "crop-frame relative aspect-square overflow-hidden bg-stage",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: file.afterUrl,
									alt: "After auto-upscale, 5000 by 5000 pixels",
									className: "absolute inset-0 h-full w-full object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute inset-y-0 left-0 overflow-hidden border-r-2 border-accent",
									style: { width: `${split}%` },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: file.beforeUrl,
										alt: "Before, original 1024 by 1024 pixels",
										className: "absolute top-0 left-0 h-full max-w-none object-cover",
										style: { width: `${frameWidth}px` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-3 left-3 bg-stage px-2 py-1 text-xs text-stage-fg",
									children: "Before · 1024 px"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute top-3 right-3 bg-stage px-2 py-1 text-xs text-stage-fg",
									children: "After · 5000 px"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "compare-range absolute inset-x-6 bottom-2",
									type: "range",
									min: 2,
									max: 98,
									value: split,
									"aria-label": "Drag to compare 1024 pixels against 5000 pixels",
									onChange: (event) => setSplit(Number(event.target.value))
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "crop-frame grid aspect-square place-items-center bg-stage px-6 text-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-4xl text-stage-fg",
								children: "5000 px"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-3 max-w-sm text-sm text-stage-fg",
								children: "Generate a square master. The engine upscales it here, then writes the Shutterstock title and keywords."
							})] })
						})
					]
				}), file ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spec, {
								label: "Dimensions",
								value: "5000×5000 px"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spec, {
								label: "Resolution",
								value: `${file.dpi || "—"} DPI`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spec, {
								label: "File weight",
								value: formatMb(file.bytes),
								note: inProfile ? "15–20 MB profile" : "Target 15–20 MB"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spec, {
								label: "JPEG quality",
								value: "100%"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							className: "rounded-lg border border-line bg-paper p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: file.beforePeek,
								alt: "100 percent crop of the 1024 master, nearest neighbor",
								className: "aspect-square w-full border border-line object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
								className: "mt-2 text-sm text-muted",
								children: "Before · 1024 px crop, pixels blown up"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							className: "rounded-lg border border-line bg-paper p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: file.afterPeek,
								alt: "100 percent crop of the 5000 pixel upscale",
								className: "aspect-square w-full border border-line object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
								className: "mt-2 text-sm text-muted",
								children: "After · true 5000 px pixels"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-line bg-paper p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
									className: "size-5 text-ink",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: "Shutterstock validator"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `grid size-20 -rotate-6 place-items-center rounded-full border-4 font-display text-xl ${validatorPass ? "border-pass text-pass" : "border-fail text-fail"}`,
								children: validatorPass ? "PASS" : "FAIL"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-2 space-y-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
									ok: pixelsOk,
									label: "Longer side above 4000 px",
									detail: `${file.width}×${file.height} px`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
									ok: sizeOk,
									label: "File heavier than 4 MB",
									detail: formatMb(file.bytes)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
									ok: dpiOk,
									label: "300 DPI embedded in the JPEG",
									detail: file.dpi ? `${file.dpi} DPI` : "Missing JFIF density"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
									ok: noText,
									label: "No text",
									detail: file.textIntent ? "Prompt asks for lettering" : file.analysis.hasText ? "Glyph-like bands detected" : "No lettering detected"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-line bg-paper p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: "Title and 40 keywords"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: rebuildMeta,
									className: "h-11 rounded-md border border-line px-3 text-sm",
									children: "Rebuild from image"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Written automatically when the 5000 px file locked. Ranked for Shutterstock, most important first."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 block text-sm text-muted",
								htmlFor: "title",
								children: [
									"Title · ",
									title.length,
									"/180"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								id: "title",
								value: title,
								onChange: (event) => setTitle(event.target.value),
								rows: 3,
								className: "mt-1 w-full resize-none rounded-md border border-line bg-bg px-3 py-2 text-sm outline-none focus-visible:outline-2 focus-visible:outline-accent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => copyText("title", title),
									className: "inline-flex h-11 items-center gap-2 rounded-md border border-line px-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
										className: "size-4",
										"aria-hidden": "true"
									}), copied === "title" ? "Copied" : "Copy title"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-4 block text-sm text-muted",
								htmlFor: "keywords",
								children: [
									"Keywords · ",
									keywords.length,
									"/40"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								id: "keywords",
								value: keywordText,
								onChange: (event) => setKeywordText(event.target.value),
								rows: 6,
								className: "mt-1 w-full resize-y rounded-md border border-line bg-bg px-3 py-2 text-sm outline-none focus-visible:outline-2 focus-visible:outline-accent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: keywords.slice(0, 40).map((keyword) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-md bg-bg px-2 py-1 text-xs text-ink",
									children: keyword
								}, keyword))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => copyText("keys", keywords.slice(0, 40).join(", ")),
									className: "inline-flex h-11 items-center gap-2 rounded-md border border-line px-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
										className: "size-4",
										"aria-hidden": "true"
									}), copied === "keys" ? "Copied" : "Copy 40 keywords"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => copyText("all", `Filename: ${jpgName}\nTitle: ${title}\nKeywords: ${keywords.slice(0, 40).join(", ")}`),
									className: "inline-flex h-11 items-center gap-2 rounded-md border border-line px-3 text-sm",
									children: copied === "all" ? "Copied" : "Copy metadata"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => downloadBlob(file.jpeg, jpgName),
							className: "inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-md bg-ink text-sm text-paper",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									className: "size-4",
									"aria-hidden": "true"
								}),
								"Download ",
								jpgName
							]
						}), file.mode === "vector" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onTrace,
							disabled: phase === "tracing",
							className: "inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-md bg-accent text-sm text-accent-ink disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenTool, {
								className: "size-4",
								"aria-hidden": "true"
							}), phase === "tracing" ? "Tracing…" : "Trace to Vector EPS"]
						}) : null]
					}),
					trace ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg border border-line bg-paper p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 sm:grid-cols-[12rem_minmax(0,1fr)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: trace.svgUrl,
								alt: "Vector trace preview",
								className: "aspect-square w-full border border-line bg-bg object-contain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: "Vector EPS"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: ["imagetracer paths on a 5000×5000 pt artboard, Illustrator 10 compatible EPS, plus the 5000 px JPEG preview.", ` ${trace.paths} filled paths.`]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex flex-col gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => downloadBlob(trace.eps, epsName),
										className: "inline-flex h-11 items-center justify-center gap-2 rounded-md border border-line text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
											className: "size-4",
											"aria-hidden": "true"
										}), epsName]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => downloadBlob(file.jpeg, jpgName),
										className: "inline-flex h-11 items-center justify-center gap-2 rounded-md border border-line text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
												className: "size-4",
												"aria-hidden": "true"
											}),
											"JPG preview ",
											jpgName
										]
									})]
								})
							] })]
						})
					}) : null
				] }) : null]
			})]
		})]
	});
}
function Spec({ label, value, note }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-paper px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-xl text-ink tabular-nums",
				children: value
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: note
			}) : null
		]
	});
}
function CheckRow({ ok, label, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: `flex items-start justify-between gap-3 rounded-md px-3 py-2 ${ok ? "bg-pass-bg text-pass" : "bg-fail-bg text-fail"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-start gap-2",
			children: [ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "mt-0.5 size-4 shrink-0",
				"aria-hidden": "true"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
				className: "mt-0.5 size-4 shrink-0",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-right text-xs",
			children: detail
		})]
	});
}
function loadHtmlImage(src) {
	return new Promise((resolve, reject) => {
		const image = new Image();
		image.onload = () => resolve(image);
		image.onerror = () => reject(/* @__PURE__ */ new Error("Could not read the generated image."));
		image.src = src;
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Studio, {});
}
//#endregion
export { Home as component };
