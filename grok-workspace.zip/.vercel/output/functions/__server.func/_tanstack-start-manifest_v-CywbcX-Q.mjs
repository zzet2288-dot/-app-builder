//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CywbcX-Q.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DEuv1PAZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DEuv1PAZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DV8k2GHO.js"]
	}
} });
//#endregion
export { tsrStartManifest };
