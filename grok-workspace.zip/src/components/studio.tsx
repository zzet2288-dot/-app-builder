import { useEffect, useRef, useState } from "react";
import { Check, Copy, Download, PenTool, ShieldCheck, X } from "lucide-react";
import { analyzeImage, promptRequestsText, type ImageAnalysis } from "@/lib/analyze";
import { generateStockImage } from "@/lib/generate-image";
import { readJpegDpi } from "@/lib/jpeg-dpi";
import { paintLocalComp } from "@/lib/local-comp";
import { buildStockMeta, fileBase, parseKeywordText, type StockMode } from "@/lib/stock-meta";

const SESSION_CAP = 8;
const SESSION_KEY = "stockgen-gens";

const PRESETS: { label: string; mode: StockMode; keyword: string; prompt: string }[] = [
  {
    label: "Cafe pour",
    mode: "photo",
    keyword: "coffee",
    prompt: "Close-up of a ceramic cup of coffee on linen with soft morning window light",
  },
  {
    label: "Coast road",
    mode: "photo",
    keyword: "coast",
    prompt: "Winding coastal road above turquoise water in late afternoon sun, empty of people",
  },
  {
    label: "Oak kitchen",
    mode: "photo",
    keyword: "kitchen",
    prompt: "Modern oak kitchen island with a ceramic bowl of lemons and soft side light",
  },
  {
    label: "Courier",
    mode: "vector",
    keyword: "courier",
    prompt: "Delivery courier riding a bicycle with a parcel and simple city shapes behind",
  },
  {
    label: "Desk plant",
    mode: "vector",
    keyword: "workspace",
    prompt: "Desk with a laptop, monstera plant, and coffee mug in flat geometric shapes",
  },
];

type Phase = "idle" | "generating" | "upscaling" | "ready" | "tracing";

type ExportFile = {
  mode: StockMode;
  prompt: string;
  width: number;
  height: number;
  dpi: number;
  bytes: number;
  beforeUrl: string;
  afterUrl: string;
  beforePeek: string;
  afterPeek: string;
  jpeg: Blob;
  analysis: ImageAnalysis;
  textIntent: boolean;
};

type TraceFile = { eps: Blob; svgUrl: string; paths: number };

function formatMb(bytes: number): string {
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2500);
}

function loadUsed(): number {
  try {
    return Number(sessionStorage.getItem(SESSION_KEY) || "0") || 0;
  } catch {
    return 0;
  }
}

export function Studio() {
  const [mode, setMode] = useState<StockMode>("photo");
  const [prompt, setPrompt] = useState(PRESETS[0].prompt);
  const [primary, setPrimary] = useState(PRESETS[0].keyword);
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("Engine idle");
  const [error, setError] = useState("");
  const [file, setFile] = useState<ExportFile | null>(null);
  const [title, setTitle] = useState("");
  const [keywordText, setKeywordText] = useState("");
  const [trace, setTrace] = useState<TraceFile | null>(null);
  const [copied, setCopied] = useState("");
  const [remaining, setRemaining] = useState(SESSION_CAP);
  const [split, setSplit] = useState(54);
  const frameRef = useRef<HTMLDivElement>(null);
  const [frameWidth, setFrameWidth] = useState(640);
  const masterRef = useRef<HTMLCanvasElement | null>(null);
  const urlsRef = useRef<string[]>([]);

  useEffect(() => {
    setRemaining(Math.max(0, SESSION_CAP - loadUsed()));
  }, []);

  useEffect(() => {
    const el = frameRef.current;
    if (!el) return;
    const measure = () => setFrameWidth(el.clientWidth);
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(el);
    return () => observer.disconnect();
  }, [file]);

  useEffect(() => {
    return () => {
      for (const url of urlsRef.current) URL.revokeObjectURL(url);
    };
  }, []);

  const keywords = parseKeywordText(keywordText);
  const base = fileBase(primary || keywords[0] || "stock");
  const jpgName = `${base}.jpg`;
  const epsName = `${base}.eps`;
  const busy = phase === "generating" || phase === "upscaling" || phase === "tracing";

  async function copyText(key: string, value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(key);
      window.setTimeout(() => setCopied((current) => (current === key ? "" : current)), 1400);
    } catch {
      setCopied("");
    }
  }

  function rememberUrl(url: string) {
    urlsRef.current.push(url);
  }

  async function upscaleMaster(source: CanvasImageSource, width: number, height: number, sourceMode: StockMode, sourcePrompt: string) {
    const master = document.createElement("canvas");
    master.width = 1024;
    master.height = 1024;
    const ctx = master.getContext("2d", { willReadFrequently: true });
    if (!ctx) throw new Error("Could not open a canvas.");
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    const cover = Math.max(1024 / width, 1024 / height);
    const dw = width * cover;
    const dh = height * cover;
    ctx.drawImage(source, (1024 - dw) / 2, (1024 - dh) / 2, dw, dh);
    masterRef.current = master;

    const analysis = analyzeImage(ctx.getImageData(0, 0, 1024, 1024));
    const beforeUrl = master.toDataURL("image/jpeg", 0.92);
    const peek = document.createElement("canvas");
    peek.width = 220;
    peek.height = 220;
    const peekCtx = peek.getContext("2d");
    if (!peekCtx) throw new Error("Could not build the comparison crop.");
    peekCtx.imageSmoothingEnabled = false;
    const span = 220 * (1024 / 5000);
    peekCtx.drawImage(master, 512 - span / 2, 512 - span / 2, span, span, 0, 0, 220, 220);
    const beforePeek = peek.toDataURL("image/jpeg", 0.92);

    setPhase("upscaling");
    setProgress(8);
    setStatus("Auto-upscale engine starting");

    const bitmap = await createImageBitmap(master);
    const worker = new Worker(new URL("../lib/upscale.worker.ts", import.meta.url), { type: "module" });
    try {
      const result = await new Promise<{ jpeg: ArrayBuffer; preview: ArrayBuffer; peek: ArrayBuffer; dpi: number }>(
        (resolve, reject) => {
          worker.onmessage = (event: MessageEvent) => {
            const data = event.data as {
              type: string;
              pct?: number;
              label?: string;
              message?: string;
              jpeg?: ArrayBuffer;
              preview?: ArrayBuffer;
              peek?: ArrayBuffer;
              dpi?: number;
            };
            if (data.type === "progress") {
              setProgress(data.pct ?? 0);
              setStatus(data.label ?? "Upscaling");
            } else if (data.type === "done" && data.jpeg && data.preview && data.peek) {
              resolve({ jpeg: data.jpeg, preview: data.preview, peek: data.peek, dpi: data.dpi ?? 0 });
            } else if (data.type === "error") {
              reject(new Error(data.message || "Upscale failed."));
            }
          };
          worker.onerror = () => reject(new Error("The upscale engine stopped."));
          worker.postMessage({ bitmap, mode: sourceMode }, [bitmap]);
        },
      );

      const jpegBytes = new Uint8Array(result.jpeg);
      const dpi = readJpegDpi(jpegBytes) ?? result.dpi;
      const afterUrl = URL.createObjectURL(new Blob([result.preview], { type: "image/jpeg" }));
      const afterPeek = URL.createObjectURL(new Blob([result.peek], { type: "image/jpeg" }));
      rememberUrl(afterUrl);
      rememberUrl(afterPeek);
      const jpeg = new Blob([jpegBytes], { type: "image/jpeg" });

      const meta = buildStockMeta({
        prompt: sourcePrompt,
        mode: sourceMode,
        primary: primary.trim() || sourcePrompt,
        colors: analysis.colors,
        hasCopySpace: analysis.hasCopySpace,
        brightness: analysis.brightness,
        saturation: analysis.saturation,
      });

      setTitle(meta.title);
      setKeywordText(meta.keywords.join(", "));
      setTrace(null);
      setFile({
        mode: sourceMode,
        prompt: sourcePrompt,
        width: 5000,
        height: 5000,
        dpi,
        bytes: jpegBytes.byteLength,
        beforeUrl,
        afterUrl,
        beforePeek,
        afterPeek,
        jpeg,
        analysis,
        textIntent: promptRequestsText(sourcePrompt),
      });
      setProgress(100);
      setStatus("5000 px locked · title and 40 keywords written");
      setPhase("ready");
    } finally {
      worker.terminate();
    }
  }

  async function onGenerate() {
    if (busy) return;
    setError("");
    if (loadUsed() >= SESSION_CAP) {
      setError("Live render limit reached for this session. Use a studio comp, or refresh later.");
      return;
    }
    setPhase("generating");
    setProgress(4);
    setStatus("Composing the 1024 master");
    try {
      const response = await generateStockImage({ data: { prompt, mode } });
      if (!response.ok) throw new Error(response.error);
      const used = loadUsed() + 1;
      sessionStorage.setItem(SESSION_KEY, String(used));
      setRemaining(Math.max(0, SESSION_CAP - used));
      const dataUrl = `data:${response.mime};base64,${response.base64}`;
      const image = await loadHtmlImage(dataUrl);
      await upscaleMaster(image, image.naturalWidth, image.naturalHeight, mode, prompt);
    } catch (err) {
      setPhase(file ? "ready" : "idle");
      setError(err instanceof Error ? err.message : "Generation failed.");
    }
  }

  async function onComp() {
    if (busy) return;
    setError("");
    setPhase("generating");
    setStatus("Painting a local studio comp");
    setProgress(6);
    try {
      const canvas = paintLocalComp(prompt, mode);
      await upscaleMaster(canvas, 1024, 1024, mode, prompt);
    } catch (err) {
      setPhase(file ? "ready" : "idle");
      setError(err instanceof Error ? err.message : "Studio comp failed.");
    }
  }

  async function onTrace() {
    const master = masterRef.current;
    if (!master || !file || file.mode !== "vector" || phase === "tracing") return;
    setPhase("tracing");
    setStatus("Tracing paths to Illustrator 10 EPS");
    setError("");
    try {
      const bitmap = await createImageBitmap(master);
      const worker = new Worker(new URL("../lib/trace.worker.ts", import.meta.url), { type: "module" });
      const traced = await new Promise<{ eps: string; svg: string; paths: number }>((resolve, reject) => {
        worker.onmessage = (event: MessageEvent) => {
          const data = event.data as { type: string; eps?: string; svg?: string; paths?: number; message?: string };
          if (data.type === "done" && data.eps && data.svg) {
            resolve({ eps: data.eps, svg: data.svg, paths: data.paths ?? 0 });
          } else if (data.type === "error") {
            reject(new Error(data.message || "Trace failed."));
          }
        };
        worker.onerror = () => reject(new Error("Vector tracer stopped."));
        worker.postMessage({ bitmap, title: epsName }, [bitmap]);
      });
      worker.terminate();
      const eps = new Blob([traced.eps], { type: "application/postscript" });
      const svgUrl = URL.createObjectURL(new Blob([traced.svg], { type: "image/svg+xml" }));
      rememberUrl(svgUrl);
      setTrace({ eps, svgUrl, paths: traced.paths });
      setStatus(`Vector locked · ${traced.paths} paths`);
      setPhase("ready");
      downloadBlob(eps, epsName);
    } catch (err) {
      setPhase("ready");
      setError(err instanceof Error ? err.message : "Trace failed.");
    }
  }

  function rebuildMeta() {
    if (!file) return;
    const meta = buildStockMeta({
      prompt: file.prompt,
      mode: file.mode,
      primary,
      colors: file.analysis.colors,
      hasCopySpace: file.analysis.hasCopySpace,
      brightness: file.analysis.brightness,
      saturation: file.analysis.saturation,
    });
    setTitle(meta.title);
    setKeywordText(meta.keywords.join(", "));
  }

  const noText = file ? !file.analysis.hasText && !file.textIntent : false;
  const pixelsOk = !!file && file.width > 4000 && file.height > 4000;
  const sizeOk = !!file && file.bytes > 4 * 1024 * 1024;
  const dpiOk = !!file && file.dpi === 300;
  const validatorPass = pixelsOk && sizeOk && dpiOk && noText;
  const inProfile = !!file && file.bytes >= 15 * 1024 * 1024 && file.bytes <= 20 * 1024 * 1024;

  return (
    <main className="min-h-screen bg-bg text-ink">
      <header className="border-b border-line bg-paper">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-4 py-4">
          <div className="flex items-center gap-3">
            <span className="grid size-11 place-items-center bg-accent font-display text-xl text-accent-ink">Sg</span>
            <div>
              <h1 className="font-display text-3xl leading-none text-ink">
                StockGen <span className="text-accent italic">AI</span>
              </h1>
              <p className="text-sm text-muted">Contributor desk · auto-upscale to 5000 px</p>
            </div>
          </div>
          <p className="text-sm text-muted tabular-nums">
            Live renders left <span className="text-ink">{remaining}</span> / {SESSION_CAP}
          </p>
        </div>
      </header>

      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-6 lg:grid-cols-[22rem_minmax(0,1fr)]">
        <section className="flex flex-col gap-4">
          <div className="rounded-lg border border-line bg-paper p-4">
            <p className="text-xs tracking-wide text-muted uppercase">Auto-upscale engine</p>
            <p className="mt-2 text-sm text-ink">
              Every generate locks a 1024 master, then rebuilds it in the browser to 5000×5000, 300 DPI, JPEG quality 100%.
              Title and 40 Shutterstock keywords are written the moment the upscale finishes.
            </p>
            <ol className="mt-3 space-y-1 text-sm text-muted">
              <li>1 · Source 1024×1024</li>
              <li>2 · Canvas passes 2048 → 4096 → 5000</li>
              <li>3 · JFIF tag set to 300 DPI</li>
              <li>4 · Metadata: title + 40 keywords</li>
            </ol>
          </div>

          <div className="rounded-lg border border-line bg-paper p-4">
            <div className="grid grid-cols-2 gap-2">
              {(["photo", "vector"] as const).map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setMode(item)}
                  className={`h-11 rounded-md border text-sm ${
                    mode === item ? "border-ink bg-ink text-paper" : "border-line bg-bg text-ink"
                  }`}
                >
                  {item === "photo" ? "Photo" : "Vector"}
                </button>
              ))}
            </div>
            <label className="mt-4 block text-sm text-muted" htmlFor="prompt">
              Prompt
            </label>
            <textarea
              id="prompt"
              value={prompt}
              onChange={(event) => setPrompt(event.target.value)}
              rows={5}
              maxLength={500}
              className="mt-1 w-full resize-none rounded-md border border-line bg-bg px-3 py-2 text-sm text-ink outline-none focus-visible:outline-2 focus-visible:outline-accent"
            />
            <label className="mt-3 block text-sm text-muted" htmlFor="keyword">
              Filename keyword
            </label>
            <input
              id="keyword"
              value={primary}
              onChange={(event) => setPrimary(event.target.value)}
              className="mt-1 h-11 w-full rounded-md border border-line bg-bg px-3 text-sm text-ink outline-none focus-visible:outline-2 focus-visible:outline-accent"
            />
            <p className="mt-2 text-xs break-all text-muted">{jpgName}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {PRESETS.map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => {
                    setMode(preset.mode);
                    setPrompt(preset.prompt);
                    setPrimary(preset.keyword);
                  }}
                  className="h-11 rounded-md border border-line bg-bg px-3 text-sm text-ink"
                >
                  {preset.label}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={onGenerate}
              disabled={busy || prompt.trim().length < 3}
              className="mt-4 h-11 w-full rounded-md bg-accent text-sm text-accent-ink disabled:opacity-50"
            >
              {phase === "generating" ? "Composing 1024…" : "Generate 1024 + auto-upscale"}
            </button>
            <button
              type="button"
              onClick={onComp}
              disabled={busy || prompt.trim().length < 3}
              className="mt-2 h-11 w-full rounded-md border border-line bg-bg text-sm text-ink disabled:opacity-50"
            >
              Studio comp · no model credit
            </button>
            {error ? <p className="mt-3 text-sm text-fail">{error}</p> : null}
          </div>
        </section>

        <section className="flex min-w-0 flex-col gap-4">
          <div className="rounded-lg bg-stage p-3 text-stage-fg sm:p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <p className="text-sm">{status}</p>
              <p className="text-sm tabular-nums text-stage-fg">{busy ? `${progress}%` : file ? "Locked" : "Idle"}</p>
            </div>
            {busy ? (
              <div className="mb-3 h-1 overflow-hidden rounded-full bg-ink">
                <div className="h-full bg-accent" style={{ width: `${Math.max(4, progress)}%` }} />
              </div>
            ) : null}

            {file ? (
              <div ref={frameRef} className="crop-frame relative aspect-square overflow-hidden bg-stage">
                <img src={file.afterUrl} alt="After auto-upscale, 5000 by 5000 pixels" className="absolute inset-0 h-full w-full object-cover" />
                <div className="absolute inset-y-0 left-0 overflow-hidden border-r-2 border-accent" style={{ width: `${split}%` }}>
                  <img
                    src={file.beforeUrl}
                    alt="Before, original 1024 by 1024 pixels"
                    className="absolute top-0 left-0 h-full max-w-none object-cover"
                    style={{ width: `${frameWidth}px` }}
                  />
                </div>
                <span className="absolute top-3 left-3 bg-stage px-2 py-1 text-xs text-stage-fg">Before · 1024 px</span>
                <span className="absolute top-3 right-3 bg-stage px-2 py-1 text-xs text-stage-fg">After · 5000 px</span>
                <input
                  className="compare-range absolute inset-x-6 bottom-2"
                  type="range"
                  min={2}
                  max={98}
                  value={split}
                  aria-label="Drag to compare 1024 pixels against 5000 pixels"
                  onChange={(event) => setSplit(Number(event.target.value))}
                />
              </div>
            ) : (
              <div className="crop-frame grid aspect-square place-items-center bg-stage px-6 text-center">
                <div>
                  <p className="font-display text-4xl text-stage-fg">5000 px</p>
                  <p className="mx-auto mt-3 max-w-sm text-sm text-stage-fg">
                    Generate a square master. The engine upscales it here, then writes the Shutterstock title and keywords.
                  </p>
                </div>
              </div>
            )}
          </div>

          {file ? (
            <>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Spec label="Dimensions" value="5000×5000 px" />
                <Spec label="Resolution" value={`${file.dpi || "—"} DPI`} />
                <Spec label="File weight" value={formatMb(file.bytes)} note={inProfile ? "15–20 MB profile" : "Target 15–20 MB"} />
                <Spec label="JPEG quality" value="100%" />
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <figure className="rounded-lg border border-line bg-paper p-3">
                  <img src={file.beforePeek} alt="100 percent crop of the 1024 master, nearest neighbor" className="aspect-square w-full border border-line object-cover" />
                  <figcaption className="mt-2 text-sm text-muted">Before · 1024 px crop, pixels blown up</figcaption>
                </figure>
                <figure className="rounded-lg border border-line bg-paper p-3">
                  <img src={file.afterPeek} alt="100 percent crop of the 5000 pixel upscale" className="aspect-square w-full border border-line object-cover" />
                  <figcaption className="mt-2 text-sm text-muted">After · true 5000 px pixels</figcaption>
                </figure>
              </div>

              <div className="rounded-lg border border-line bg-paper p-4">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="size-5 text-ink" aria-hidden="true" />
                    <h2 className="font-display text-2xl">Shutterstock validator</h2>
                  </div>
                  <p className={`grid size-20 -rotate-6 place-items-center rounded-full border-4 font-display text-xl ${validatorPass ? "border-pass text-pass" : "border-fail text-fail"}`}>
                    {validatorPass ? "PASS" : "FAIL"}
                  </p>
                </div>
                <ul className="mt-2 space-y-2 text-sm">
                  <CheckRow ok={pixelsOk} label="Longer side above 4000 px" detail={`${file.width}×${file.height} px`} />
                  <CheckRow ok={sizeOk} label="File heavier than 4 MB" detail={formatMb(file.bytes)} />
                  <CheckRow ok={dpiOk} label="300 DPI embedded in the JPEG" detail={file.dpi ? `${file.dpi} DPI` : "Missing JFIF density"} />
                  <CheckRow
                    ok={noText}
                    label="No text"
                    detail={
                      file.textIntent
                        ? "Prompt asks for lettering"
                        : file.analysis.hasText
                          ? "Glyph-like bands detected"
                          : "No lettering detected"
                    }
                  />
                </ul>
              </div>

              <div className="rounded-lg border border-line bg-paper p-4">
                <div className="flex flex-wrap items-end justify-between gap-2">
                  <h2 className="font-display text-2xl">Title and 40 keywords</h2>
                  <button type="button" onClick={rebuildMeta} className="h-11 rounded-md border border-line px-3 text-sm">
                    Rebuild from image
                  </button>
                </div>
                <p className="mt-1 text-sm text-muted">Written automatically when the 5000 px file locked. Ranked for Shutterstock, most important first.</p>
                <label className="mt-3 block text-sm text-muted" htmlFor="title">
                  Title · {title.length}/180
                </label>
                <textarea
                  id="title"
                  value={title}
                  onChange={(event) => setTitle(event.target.value)}
                  rows={3}
                  className="mt-1 w-full resize-none rounded-md border border-line bg-bg px-3 py-2 text-sm outline-none focus-visible:outline-2 focus-visible:outline-accent"
                />
                <div className="mt-2 flex flex-wrap gap-2">
                  <button type="button" onClick={() => copyText("title", title)} className="inline-flex h-11 items-center gap-2 rounded-md border border-line px-3 text-sm">
                    <Copy className="size-4" aria-hidden="true" />
                    {copied === "title" ? "Copied" : "Copy title"}
                  </button>
                </div>
                <label className="mt-4 block text-sm text-muted" htmlFor="keywords">
                  Keywords · {keywords.length}/40
                </label>
                <textarea
                  id="keywords"
                  value={keywordText}
                  onChange={(event) => setKeywordText(event.target.value)}
                  rows={6}
                  className="mt-1 w-full resize-y rounded-md border border-line bg-bg px-3 py-2 text-sm outline-none focus-visible:outline-2 focus-visible:outline-accent"
                />
                <div className="mt-3 flex flex-wrap gap-2">
                  {keywords.slice(0, 40).map((keyword) => (
                    <span key={keyword} className="rounded-md bg-bg px-2 py-1 text-xs text-ink">
                      {keyword}
                    </span>
                  ))}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => copyText("keys", keywords.slice(0, 40).join(", "))}
                    className="inline-flex h-11 items-center gap-2 rounded-md border border-line px-3 text-sm"
                  >
                    <Copy className="size-4" aria-hidden="true" />
                    {copied === "keys" ? "Copied" : "Copy 40 keywords"}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      copyText("all", `Filename: ${jpgName}\nTitle: ${title}\nKeywords: ${keywords.slice(0, 40).join(", ")}`)
                    }
                    className="inline-flex h-11 items-center gap-2 rounded-md border border-line px-3 text-sm"
                  >
                    {copied === "all" ? "Copied" : "Copy metadata"}
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-2 sm:flex-row">
                <button
                  type="button"
                  onClick={() => downloadBlob(file.jpeg, jpgName)}
                  className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-md bg-ink text-sm text-paper"
                >
                  <Download className="size-4" aria-hidden="true" />
                  Download {jpgName}
                </button>
                {file.mode === "vector" ? (
                  <button
                    type="button"
                    onClick={onTrace}
                    disabled={phase === "tracing"}
                    className="inline-flex h-11 flex-1 items-center justify-center gap-2 rounded-md bg-accent text-sm text-accent-ink disabled:opacity-50"
                  >
                    <PenTool className="size-4" aria-hidden="true" />
                    {phase === "tracing" ? "Tracing…" : "Trace to Vector EPS"}
                  </button>
                ) : null}
              </div>

              {trace ? (
                <div className="rounded-lg border border-line bg-paper p-4">
                  <div className="grid gap-4 sm:grid-cols-[12rem_minmax(0,1fr)]">
                    <img src={trace.svgUrl} alt="Vector trace preview" className="aspect-square w-full border border-line bg-bg object-contain" />
                    <div>
                      <h2 className="font-display text-2xl">Vector EPS</h2>
                      <p className="mt-1 text-sm text-muted">
                        imagetracer paths on a 5000×5000 pt artboard, Illustrator 10 compatible EPS, plus the 5000 px JPEG preview.
                        {` ${trace.paths} filled paths.`}
                      </p>
                      <div className="mt-3 flex flex-col gap-2">
                        <button
                          type="button"
                          onClick={() => downloadBlob(trace.eps, epsName)}
                          className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-line text-sm"
                        >
                          <Download className="size-4" aria-hidden="true" />
                          {epsName}
                        </button>
                        <button
                          type="button"
                          onClick={() => downloadBlob(file.jpeg, jpgName)}
                          className="inline-flex h-11 items-center justify-center gap-2 rounded-md border border-line text-sm"
                        >
                          <Download className="size-4" aria-hidden="true" />
                          JPG preview {jpgName}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}
            </>
          ) : null}
        </section>
      </div>
    </main>
  );
}

function Spec({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="rounded-lg border border-line bg-paper px-3 py-3">
      <p className="text-xs tracking-wide text-muted uppercase">{label}</p>
      <p className="mt-1 font-display text-xl text-ink tabular-nums">{value}</p>
      {note ? <p className="text-xs text-muted">{note}</p> : null}
    </div>
  );
}

function CheckRow({ ok, label, detail }: { ok: boolean; label: string; detail: string }) {
  return (
    <li className={`flex items-start justify-between gap-3 rounded-md px-3 py-2 ${ok ? "bg-pass-bg text-pass" : "bg-fail-bg text-fail"}`}>
      <span className="flex items-start gap-2">
        {ok ? <Check className="mt-0.5 size-4 shrink-0" aria-hidden="true" /> : <X className="mt-0.5 size-4 shrink-0" aria-hidden="true" />}
        <span>{label}</span>
      </span>
      <span className="text-right text-xs">{detail}</span>
    </li>
  );
}

function loadHtmlImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Could not read the generated image."));
    image.src = src;
  });
}
