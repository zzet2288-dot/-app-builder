declare module "imagetracerjs" {
  interface TracerSegment {
    type: string;
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    x3?: number;
    y3?: number;
  }

  interface TracerPath {
    segments: TracerSegment[];
    holechildren: number[];
    isholepath: boolean;
  }

  interface TraceData {
    layers: TracerPath[][];
    palette: { r: number; g: number; b: number; a: number }[];
    width: number;
    height: number;
  }

  interface ImageTracerApi {
    imagedataToTracedata(imgd: ImageData, options?: Record<string, unknown>): TraceData;
    imagedataToSVG(imgd: ImageData, options?: Record<string, unknown>): string;
  }

  const ImageTracer: ImageTracerApi;
  export default ImageTracer;
}
