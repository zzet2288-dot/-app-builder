export type Brightness = "bright" | "balanced" | "dark";
export type Saturation = "vivid" | "natural" | "muted";

export type ImageAnalysis = {
  colors: string[];
  hasCopySpace: boolean;
  brightness: Brightness;
  saturation: Saturation;
  hasText: boolean;
  textConfidence: number;
};

const TEXT_INTENT =
  /\b(typography|lettering|watermark|caption|headline|slogan|alphabet|inscription|font|logo|words)\b|["“][^"”]{2,}["”]|\b(text|that says|with the word|says)\b/i;

export function promptRequestsText(prompt: string): boolean {
  return TEXT_INTENT.test(prompt);
}

function clampHue(h: number): number {
  const x = h % 360;
  return x < 0 ? x + 360 : x;
}

function colorName(r: number, g: number, b: number): string | null {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const l = (max + min) / 2 / 255;
  const d = max - min;
  const s = d === 0 ? 0 : d / 255 / (1 - Math.abs(2 * l - 1));
  if (l > 0.92) return "white";
  if (l < 0.08) return "black";
  if (s < 0.12) return l > 0.62 ? "gray" : "charcoal";
  let h = 0;
  if (d !== 0) {
    if (max === r) h = ((g - b) / d) * 60;
    else if (max === g) h = ((b - r) / d) * 60 + 120;
    else h = ((r - g) / d) * 60 + 240;
  }
  h = clampHue(h);
  if (l > 0.82 && s < 0.35) return "cream";
  if (h < 18 || h >= 348) return l < 0.35 ? "burgundy" : "red";
  if (h < 40) return l < 0.45 ? "brown" : "orange";
  if (h < 55) return s < 0.45 ? "beige" : "amber";
  if (h < 70) return "yellow";
  if (h < 95) return "lime";
  if (h < 150) return l < 0.28 ? "forest" : "green";
  if (h < 180) return "teal";
  if (h < 200) return "cyan";
  if (h < 250) return l < 0.32 ? "navy" : "blue";
  if (h < 290) return "indigo";
  if (h < 330) return "purple";
  return "pink";
}

function median(values: Float32Array): number {
  const copy = Array.from(values).sort((a, b) => a - b);
  const mid = Math.floor(copy.length / 2);
  return copy.length % 2 ? copy[mid] : (copy[mid - 1] + copy[mid]) / 2;
}

function detectText(data: ImageData): { hasText: boolean; confidence: number } {
  const { width, height, data: px } = data;
  const cols = 96;
  const rows = 96;
  const stepX = width / cols;
  const stepY = height / rows;
  const rowTrans = new Float32Array(rows);

  const lum = (x: number, y: number) => {
    const ix = Math.min(width - 1, Math.max(0, Math.round(x)));
    const iy = Math.min(height - 1, Math.max(0, Math.round(y)));
    const i = (iy * width + ix) * 4;
    return px[i] * 0.299 + px[i + 1] * 0.587 + px[i + 2] * 0.114;
  };

  for (let y = 0; y < rows; y++) {
    let trans = 0;
    let prevEdge = false;
    const py = (y + 0.5) * stepY;
    for (let x = 0; x < cols - 1; x++) {
      const edge = Math.abs(lum((x + 1.5) * stepX, py) - lum((x + 0.5) * stepX, py)) > 48;
      if (edge && !prevEdge) trans += 1;
      prevEdge = edge;
    }
    rowTrans[y] = trans;
  }

  const mid = median(rowTrans);
  let bands = 0;
  let y = 1;
  while (y < rows - 1) {
    const hot = rowTrans[y] >= 7 && rowTrans[y] <= 26 && rowTrans[y] > mid * 2;
    if (!hot) {
      y += 1;
      continue;
    }
    let end = y;
    while (end < rows - 1 && rowTrans[end] >= 6 && rowTrans[end] <= 28) end += 1;
    const heightRows = end - y;
    if (heightRows >= 2 && heightRows <= 6) {
      let sum = 0;
      for (let i = y; i < end; i++) sum += rowTrans[i];
      const avg = sum / heightRows;
      const above = rowTrans[Math.max(0, y - 2)];
      const below = rowTrans[Math.min(rows - 1, end + 1)];
      if (avg > above * 1.8 && avg > below * 1.8) bands += 1;
    }
    y = Math.max(end, y + 1);
  }

  const confidence = Math.min(1, bands / 4);
  return { hasText: bands >= 3, confidence };
}

export function analyzeImage(data: ImageData): ImageAnalysis {
  const { width, height, data: px } = data;
  const votes = new Map<string, number>();
  let lumSum = 0;
  let satSum = 0;
  let samples = 0;
  const quadLum: number[][] = [[], [], [], []];
  const step = 8;

  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const i = (y * width + x) * 4;
      const r = px[i];
      const g = px[i + 1];
      const b = px[i + 2];
      const lum = (r * 0.299 + g * 0.587 + b * 0.114) / 255;
      const max = Math.max(r, g, b) / 255;
      const min = Math.min(r, g, b) / 255;
      const sat = max === 0 ? 0 : (max - min) / max;
      lumSum += lum;
      satSum += sat;
      samples += 1;
      const name = colorName(r, g, b);
      if (name) votes.set(name, (votes.get(name) ?? 0) + 1);
      const qi = (x < width / 2 ? 0 : 1) + (y < height / 2 ? 0 : 2);
      quadLum[qi].push(lum);
    }
  }

  const colors = [...votes.entries()]
    .sort((a, b) => b[1] - a[1])
    .filter(([, count]) => count / samples > 0.08)
    .slice(0, 3)
    .map(([name]) => name);

  const meanLum = lumSum / Math.max(1, samples);
  const meanSat = satSum / Math.max(1, samples);
  const brightness: Brightness = meanLum > 0.68 ? "bright" : meanLum < 0.32 ? "dark" : "balanced";
  const saturation: Saturation = meanSat > 0.42 ? "vivid" : meanSat < 0.16 ? "muted" : "natural";

  let hasCopySpace = false;
  for (const values of quadLum) {
    if (values.length < 8) continue;
    const mean = values.reduce((s, v) => s + v, 0) / values.length;
    const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length;
    const std = Math.sqrt(variance);
    if (std < 0.07 && (mean > 0.72 || mean < 0.16)) hasCopySpace = true;
  }

  const text = detectText(data);
  return {
    colors,
    hasCopySpace,
    brightness,
    saturation,
    hasText: text.hasText,
    textConfidence: text.confidence,
  };
}
