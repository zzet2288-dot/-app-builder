export type TracerSegment = {
  type: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  x3?: number;
  y3?: number;
};

export type TracerPath = {
  segments: TracerSegment[];
  holechildren: number[];
  isholepath: boolean;
};

export type TraceData = {
  layers: TracerPath[][];
  palette: { r: number; g: number; b: number; a: number }[];
  width: number;
  height: number;
};

const ARTBOARD = 5000;

function n(value: number): string {
  return (Math.round(value * 100) / 100).toFixed(2);
}

function escapePs(value: string): string {
  return value.replace(/[()\\]/g, "\\$&");
}

function subpath(
  path: TracerPath,
  xOf: (x: number) => number,
  yOf: (y: number) => number,
): string[] {
  if (!path.segments.length) return [];
  const lines: string[] = [];
  const first = path.segments[0];
  lines.push(`${n(xOf(first.x1))} ${n(yOf(first.y1))} moveto`);
  let cx = first.x1;
  let cy = first.y1;
  for (const segment of path.segments) {
    if (Math.hypot(segment.x1 - cx, segment.y1 - cy) > 0.4) {
      lines.push(`${n(xOf(segment.x1))} ${n(yOf(segment.y1))} moveto`);
    }
    if (segment.type === "Q" && segment.x3 != null && segment.y3 != null) {
      const x0 = xOf(segment.x1);
      const y0 = yOf(segment.y1);
      const xc = xOf(segment.x2);
      const yc = yOf(segment.y2);
      const x = xOf(segment.x3);
      const y = yOf(segment.y3);
      const c1x = x0 + (2 / 3) * (xc - x0);
      const c1y = y0 + (2 / 3) * (yc - y0);
      const c2x = x + (2 / 3) * (xc - x);
      const c2y = y + (2 / 3) * (yc - y);
      lines.push(`${n(c1x)} ${n(c1y)} ${n(c2x)} ${n(c2y)} ${n(x)} ${n(y)} curveto`);
      cx = segment.x3;
      cy = segment.y3;
    } else {
      lines.push(`${n(xOf(segment.x2))} ${n(yOf(segment.y2))} lineto`);
      cx = segment.x2;
      cy = segment.y2;
    }
  }
  lines.push("closepath");
  return lines;
}

export function traceDataToEps(traced: TraceData, title: string): { eps: string; paths: number } {
  const scaleX = ARTBOARD / Math.max(1, traced.width);
  const scaleY = ARTBOARD / Math.max(1, traced.height);
  const xOf = (x: number) => x * scaleX;
  const yOf = (y: number) => (traced.height - y) * scaleY;
  const body: string[] = [];
  let paths = 0;

  traced.layers.forEach((layer, layerIndex) => {
    const color = traced.palette[layerIndex];
    if (!color || color.a < 12) return;
    const rgb = [color.r / 255, color.g / 255, color.b / 255].map((channel) => channel.toFixed(4)).join(" ");
    layer.forEach((path) => {
      if (path.isholepath || path.segments.length < 2) return;
      const commands = subpath(path, xOf, yOf);
      for (const holeIndex of path.holechildren ?? []) {
        const hole = layer[holeIndex];
        if (hole?.segments?.length) commands.push(...subpath(hole, xOf, yOf));
      }
      if (!commands.length) return;
      paths += 1;
      body.push(`${rgb} setrgbcolor`);
      body.push("newpath");
      body.push(...commands);
      body.push("eofill");
    });
  });

  const eps = [
    "%!PS-Adobe-3.0 EPSF-3.0",
    `%%BoundingBox: 0 0 ${ARTBOARD} ${ARTBOARD}`,
    `%%HiResBoundingBox: 0.0000 0.0000 ${ARTBOARD}.0000 ${ARTBOARD}.0000`,
    `%%Title: (${escapePs(title)})`,
    "%%Creator: StockGen AI (Illustrator 10 compatible EPSF)",
    "%%AI8_CreatorVersion: 10.0.0",
    "%%LanguageLevel: 2",
    "%%Pages: 1",
    "%%DocumentData: Clean7Bit",
    "%%EndComments",
    "%%BeginProlog",
    "%%EndProlog",
    "%%Page: 1 1",
    "% Solid filled paths only. No transparency, no embedded raster, LanguageLevel 2.",
    "gsave",
    ...body,
    "grestore",
    "showpage",
    "%%EOF",
    "",
  ].join("\n");

  return { eps, paths };
}

export function traceDataToSvg(traced: TraceData): string {
  const parts = [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${traced.width} ${traced.height}">`,
  ];
  traced.layers.forEach((layer, layerIndex) => {
    const color = traced.palette[layerIndex];
    if (!color || color.a < 12) return;
    const fill = `rgb(${color.r},${color.g},${color.b})`;
    for (const path of layer) {
      if (path.isholepath || path.segments.length < 2) continue;
      let d = `M ${path.segments[0].x1.toFixed(1)} ${path.segments[0].y1.toFixed(1)}`;
      for (const segment of path.segments) {
        if (segment.type === "Q" && segment.x3 != null && segment.y3 != null) {
          d += ` Q ${segment.x2.toFixed(1)} ${segment.y2.toFixed(1)} ${segment.x3.toFixed(1)} ${segment.y3.toFixed(1)}`;
        } else {
          d += ` L ${segment.x2.toFixed(1)} ${segment.y2.toFixed(1)}`;
        }
      }
      d += " Z";
      for (const holeIndex of path.holechildren ?? []) {
        const hole = layer[holeIndex];
        if (!hole?.segments.length) continue;
        const last = hole.segments[hole.segments.length - 1];
        const sx = last.x3 ?? last.x2;
        const sy = last.y3 ?? last.y2;
        d += ` M ${sx.toFixed(1)} ${sy.toFixed(1)}`;
        for (let i = hole.segments.length - 1; i >= 0; i--) {
          d += ` L ${hole.segments[i].x1.toFixed(1)} ${hole.segments[i].y1.toFixed(1)}`;
        }
        d += " Z";
      }
      parts.push(`<path fill="${fill}" fill-rule="evenodd" d="${d}"/>`);
    }
  });
  parts.push("</svg>");
  return parts.join("");
}
