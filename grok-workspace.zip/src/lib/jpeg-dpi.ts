/** Read or write the JFIF density so a canvas JPEG carries a real 300 DPI tag. */

function markerLength(bytes: Uint8Array, offset: number): number {
  return (bytes[offset + 2] << 8) | bytes[offset + 3];
}

function isStandalone(marker: number): boolean {
  return marker === 0xd8 || marker === 0xd9 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7);
}

function findJfif(bytes: Uint8Array): number {
  if (bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) return -1;
  let offset = 2;
  while (offset + 4 < bytes.length) {
    if (bytes[offset] !== 0xff) return -1;
    const marker = bytes[offset + 1];
    if (isStandalone(marker)) {
      offset += 2;
      continue;
    }
    const len = markerLength(bytes, offset);
    if (len < 2 || offset + 2 + len > bytes.length) return -1;
    if (marker === 0xe0 && len >= 16) {
      const id = String.fromCharCode(
        bytes[offset + 4],
        bytes[offset + 5],
        bytes[offset + 6],
        bytes[offset + 7],
        bytes[offset + 8],
      );
      if (id === "JFIF\0") return offset;
    }
    if (marker === 0xda) return -1;
    offset += 2 + len;
  }
  return -1;
}

export function patchJpegDpi(input: Uint8Array, dpi: number): Uint8Array {
  const hit = findJfif(input);
  if (hit >= 0) {
    input[hit + 11] = 1;
    input[hit + 12] = (dpi >> 8) & 0xff;
    input[hit + 13] = dpi & 0xff;
    input[hit + 14] = (dpi >> 8) & 0xff;
    input[hit + 15] = dpi & 0xff;
    return input;
  }
  const jfif = new Uint8Array([
    0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x02, 0x01,
    (dpi >> 8) & 0xff,
    dpi & 0xff,
    (dpi >> 8) & 0xff,
    dpi & 0xff,
    0x00, 0x00,
  ]);
  const out = new Uint8Array(2 + jfif.length + Math.max(0, input.length - 2));
  out[0] = 0xff;
  out[1] = 0xd8;
  out.set(jfif, 2);
  if (input.length > 2) out.set(input.subarray(2), 2 + jfif.length);
  return out;
}

export function readJpegDpi(bytes: Uint8Array): number | null {
  const hit = findJfif(bytes);
  if (hit < 0) return null;
  if (bytes[hit + 11] !== 1) return null;
  return (bytes[hit + 12] << 8) | bytes[hit + 13];
}
