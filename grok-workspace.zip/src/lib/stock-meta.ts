import type { Brightness, Saturation } from "@/lib/analyze";

export type StockMode = "photo" | "vector";

export type StockMetaInput = {
  prompt: string;
  mode: StockMode;
  primary: string;
  colors: string[];
  hasCopySpace: boolean;
  brightness: Brightness;
  saturation: Saturation;
};

const STOP = new Set([
  "a", "an", "the", "and", "or", "with", "of", "on", "in", "to", "for", "from", "by",
  "at", "into", "over", "near", "under", "its", "this", "that", "very", "highly",
  "beautiful", "stunning", "amazing", "image", "photo", "picture", "background",
  "wallpaper", "stock", "shutterstock", "getty", "jpg", "jpeg", "png", "eps",
  "render", "rendered", "style", "scene", "shot", "looking", "featuring", "showing",
  "without", "no", "not", "using", "use", "made", "make", "just", "really", "simple",
  "riding", "behind", "above", "below", "empty", "winding", "late", "side", "soft",
]);

const BANNED = new Set([
  "text", "watermark", "logo", "signature", "typography", "lettering", "caption",
  "4k", "8k", "hd", "uhd", "high resolution", "high quality", "best", "awesome",
  "shutterstock", "stockgen", "getty", "istock", "adobe",
]);

const RELATED: Record<string, string[]> = {
  coffee: ["espresso", "latte", "cafe", "beverage", "mug", "caffeine", "brew", "barista", "saucer", "hot drink"],
  cup: ["mug", "ceramic", "drink", "saucer", "tableware"],
  tea: ["teapot", "herbal", "beverage", "cup", "infusion"],
  kitchen: ["cooking", "counter", "culinary", "home", "interior", "utensil"],
  lemon: ["citrus", "fruit", "yellow", "zest", "fresh"],
  fruit: ["fresh", "produce", "healthy", "food", "organic"],
  food: ["cuisine", "meal", "gourmet", "ingredient", "delicious"],
  bread: ["bakery", "loaf", "wheat", "breakfast", "baked"],
  desk: ["workspace", "table", "office", "stationery", "work"],
  laptop: ["computer", "notebook", "technology", "keyboard", "remote work"],
  workspace: ["home office", "desk", "productivity", "remote work", "office"],
  office: ["business", "corporate", "workplace", "professional", "desk"],
  plant: ["houseplant", "foliage", "greenery", "botanical", "leaf"],
  monstera: ["houseplant", "tropical", "leaf", "foliage", "botanical"],
  flower: ["floral", "bloom", "petal", "botanical", "garden"],
  garden: ["outdoor", "botanical", "plant", "yard", "nature"],
  tree: ["forest", "woodland", "branch", "foliage", "nature"],
  forest: ["woodland", "trees", "nature", "wilderness", "trail"],
  mountain: ["peak", "landscape", "alpine", "hiking", "summit"],
  ocean: ["sea", "water", "wave", "marine", "seascape"],
  sea: ["ocean", "water", "coast", "marine", "horizon"],
  beach: ["shore", "sand", "coast", "seaside", "summer"],
  coast: ["coastline", "shore", "seascape", "cliff", "ocean"],
  coastline: ["coast", "shore", "aerial", "seascape", "water"],
  wave: ["water", "surf", "ocean", "ripple", "sea"],
  road: ["highway", "journey", "asphalt", "travel", "path"],
  street: ["urban", "city", "sidewalk", "downtown", "road"],
  city: ["urban", "downtown", "skyline", "metropolitan", "architecture"],
  courier: ["delivery", "parcel", "messenger", "package", "shipping"],
  bicycle: ["bike", "cycling", "cyclist", "commute", "two wheeler"],
  bike: ["bicycle", "cycling", "rider", "commute"],
  delivery: ["parcel", "shipping", "package", "courier", "logistics"],
  car: ["automobile", "vehicle", "driving", "transport", "road"],
  kitchenisland: ["kitchen", "island", "counter", "interior"],
  bowl: ["ceramic", "tableware", "dish", "kitchen"],
  window: ["daylight", "glass", "interior", "sunlight", "view"],
  sunlight: ["daylight", "sunshine", "natural light", "sunny", "morning"],
  morning: ["sunrise", "dawn", "daylight", "breakfast", "early"],
  linen: ["fabric", "textile", "cloth", "tablecloth", "texture"],
  ceramic: ["pottery", "stoneware", "handmade", "tableware"],
  abstract: ["geometric", "shape", "modern art", "pattern", "composition"],
  pattern: ["repeat", "texture", "motif", "decorative", "surface"],
  paper: ["stationery", "sheet", "craft", "texture", "layered"],
  portrait: ["person", "face", "headshot", "people", "human"],
  woman: ["female", "person", "people", "adult", "human"],
  man: ["male", "person", "people", "adult", "human"],
  hands: ["hand", "gesture", "fingers", "human", "closeup"],
  dog: ["puppy", "canine", "pet", "animal", "companion"],
  cat: ["kitten", "feline", "pet", "animal", "companion"],
  bird: ["avian", "wildlife", "feather", "animal", "wing"],
  fitness: ["exercise", "workout", "health", "active", "training"],
  yoga: ["wellness", "stretch", "mindfulness", "fitness", "pose"],
  medical: ["healthcare", "clinic", "health", "medicine", "hospital"],
  doctor: ["physician", "healthcare", "medical", "clinic", "professional"],
  phone: ["smartphone", "mobile", "device", "technology", "screen"],
  technology: ["digital", "innovation", "device", "modern", "tech"],
  fashion: ["style", "clothing", "apparel", "trend", "wardrobe"],
  shoe: ["footwear", "sneaker", "leather", "fashion"],
  interior: ["indoor", "room", "decor", "design", "home"],
  home: ["house", "domestic", "indoor", "living", "interior"],
  sofa: ["couch", "living room", "furniture", "interior", "seating"],
  table: ["furniture", "surface", "dining", "wood"],
  wood: ["wooden", "timber", "grain", "oak", "natural"],
  oak: ["wood", "timber", "furniture", "grain"],
  sky: ["clouds", "atmosphere", "horizon", "blue sky", "air"],
  sunset: ["dusk", "evening", "golden hour", "sky", "twilight"],
  island: ["tropical", "travel", "destination", "coast", "vacation"],
  travel: ["journey", "destination", "tourism", "trip", "adventure"],
  business: ["corporate", "professional", "commerce", "enterprise", "work"],
  meeting: ["conference", "team", "collaboration", "office", "discussion"],
  chart: ["graph", "analytics", "data", "statistics", "growth"],
  data: ["analytics", "information", "digital", "statistics"],
  robot: ["automation", "machine", "technology", "future", "android"],
  abstractpaper: ["paper", "layered", "craft", "texture"],
};

const CATEGORY_CUES: Record<string, string[]> = {
  food: ["coffee", "cup", "tea", "kitchen", "lemon", "bread", "fruit", "food", "meal", "cafe", "wine", "cake", "bowl", "drink"],
  nature: ["forest", "mountain", "ocean", "sea", "tree", "flower", "leaf", "plant", "sky", "beach", "water", "sunset", "river", "garden", "monstera"],
  travel: ["coast", "coastline", "road", "city", "street", "travel", "island", "hotel", "landmark", "skyline"],
  business: ["office", "desk", "laptop", "meeting", "workspace", "business", "chart", "team"],
  home: ["interior", "sofa", "bedroom", "kitchen", "furniture", "home", "room", "table", "linen"],
  animal: ["dog", "cat", "bird", "horse", "wildlife", "pet", "animal", "fish"],
  people: ["person", "woman", "man", "portrait", "face", "hands", "family", "child"],
  tech: ["phone", "computer", "technology", "data", "screen", "device", "robot", "laptop"],
  transport: ["car", "bicycle", "bike", "courier", "delivery", "train", "plane", "vehicle"],
  wellness: ["medical", "health", "doctor", "hospital", "yoga", "fitness", "wellness"],
  fashion: ["fashion", "clothes", "dress", "shoe", "fabric", "style"],
  abstract: ["abstract", "pattern", "shape", "geometric", "texture", "paper", "gradient"],
};

const CATEGORY_TAIL: Record<string, string[]> = {
  food: ["ingredient", "recipe", "fresh food", "tabletop", "still life", "culinary", "breakfast table", "homemade", "snack", "refreshment", "dining", "aroma", "kitchenware", "served", "tasty"],
  nature: ["landscape", "outdoors", "scenery", "natural", "environment", "wilderness", "organic", "ecosystem", "earth", "flora", "horizon line", "open air", "peaceful", "scenic", "conservation"],
  travel: ["destination", "getaway", "tourism", "journey", "vacation", "explore", "wanderlust", "scenic route", "trip", "adventure", "landmark view", "holiday", "abroad", "itinerary", "discovery"],
  business: ["professional", "corporate", "workplace", "career", "startup", "strategy", "productivity", "entrepreneur", "commerce", "success", "planning", "colleague", "briefcase", "deadline", "growth"],
  home: ["interior design", "decor", "domestic", "cozy", "living space", "household", "room interior", "furniture design", "comfortable", "homestyle", "indoor living", "styling", "residential", "nest", "ambiance"],
  animal: ["wildlife", "pet care", "animal portrait", "fur", "companion", "nature animal", "creature", "fauna", "loyal", "outdoors animal", "mammal", "whisker", "paw", "habitat", "zoology"],
  people: ["lifestyle", "human", "adult", "candid", "everyday life", "person portrait", "expression", "real people", "community", "individual", "character", "gesture", "skin", "looking away", "generation"],
  tech: ["digital", "innovation", "device", "modern technology", "electronics", "screen glow", "connected", "gadget", "software concept", "future", "smart device", "network", "interface", "hardware", "online"],
  transport: ["transportation", "commute", "mobility", "vehicle", "traffic", "logistics", "urban travel", "on the move", "transit", "shipping", "rider", "route", "speed", "cargo", "street travel"],
  wellness: ["healthy", "wellbeing", "self care", "balance", "clinic", "healthcare", "mind and body", "routine", "calm", "recovery", "active life", "vitality", "treatment", "prevention", "lifestyle health"],
  fashion: ["apparel", "outfit", "trend", "wardrobe", "textile", "clothing detail", "runway", "garment", "accessory", "tailoring", "seasonal style", "lookbook", "couture", "fabric texture", "styling"],
  abstract: ["modern art", "graphic", "shape study", "creative", "art print", "minimal art", "color field", "design element", "contemporary", "visual art", "form", "art background", "studio art", "composition study", "fine art"],
  general: ["still life", "detail", "everyday", "concept", "scene", "subject", "arrangement", "setting", "atmosphere", "visual", "object", "surface", "environment", "theme", "study"],
};

function sanitizeKeyword(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function significantTokens(prompt: string): string[] {
  return sanitizeKeyword(prompt)
    .split(" ")
    .filter((word) => word.length > 2 && !STOP.has(word) && !/^\d+$/.test(word));
}

function bigrams(tokens: string[]): string[] {
  const weak = new Set([
    "soft", "late", "empty", "simple", "modern", "clean", "flat", "side", "above",
    "behind", "riding", "winding", "afternoon", "close-up", "open", "small", "large",
  ]);
  const phrases: string[] = [];
  for (let i = 0; i < tokens.length - 1; i++) {
    if (weak.has(tokens[i]) || weak.has(tokens[i + 1])) continue;
    if (STOP.has(tokens[i]) || STOP.has(tokens[i + 1])) continue;
    phrases.push(`${tokens[i]} ${tokens[i + 1]}`);
  }
  return phrases;
}

function detectCategory(words: string[]): string {
  const blob = words.join(" ");
  let best = "general";
  let score = 0;
  for (const [category, cues] of Object.entries(CATEGORY_CUES)) {
    const hits = cues.reduce((n, cue) => n + (blob.includes(cue) ? 1 : 0), 0);
    if (hits > score) {
      score = hits;
      best = category;
    }
  }
  return best;
}

function cleanTitle(prompt: string, mode: StockMode, colors: string[]): string {
  const cleaned = prompt
    .replace(/\s+/g, " ")
    .replace(/[^\w\s,'’-]/g, "")
    .trim()
    .replace(/[.!?]+$/g, "");
  const base = cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
  let title = base;
  if (mode === "vector" && !/\bvector\b|\billustration\b/i.test(title)) {
    title = `Flat vector illustration of ${base.charAt(0).toLowerCase()}${base.slice(1)}`;
  } else if (mode === "photo" && title.length < 48 && colors[0]) {
    title = `${base} in ${colors[0]} tones`;
  }
  if (title.length > 180) title = title.slice(0, 177).replace(/\s+\S*$/, "");
  return title;
}

export function slugKeyword(input: string): string {
  const slug = sanitizeKeyword(input).replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 40);
  return slug || "stock";
}

export function fileBase(keyword: string): string {
  return `stockgen_ai_5000px_${slugKeyword(keyword)}`;
}

export function buildStockMeta(input: StockMetaInput): { title: string; keywords: string[] } {
  const tokens = significantTokens(input.prompt);
  const primary = sanitizeKeyword(input.primary) || tokens[0] || "stock";
  const ordered: string[] = [];
  const seen = new Set<string>();

  const add = (raw: string) => {
    const keyword = sanitizeKeyword(raw);
    if (!keyword || keyword.length < 2 || keyword.length > 32) return;
    if (seen.has(keyword) || STOP.has(keyword) || BANNED.has(keyword)) return;
    if ([...seen].some((existing) => existing.endsWith("s") === false && keyword === `${existing}s`)) return;
    const parts = keyword.split(" ");
    if (new Set(parts).size !== parts.length) return;
    seen.add(keyword);
    ordered.push(keyword);
  };

  add(primary);
  for (const token of tokens) add(token);
  for (const rel of RELATED[primary] ?? []) add(rel);
  for (const token of tokens) {
    for (const rel of RELATED[token] ?? []) add(rel);
  }
  for (const color of input.colors) add(color);
  if (input.hasCopySpace) add("copy space");
  if (input.brightness === "bright") {
    add("bright");
    add("high key");
    add("soft light");
  } else if (input.brightness === "dark") {
    add("dark");
    add("low key");
    add("moody");
  } else {
    add("natural light");
  }
  if (input.saturation === "vivid") add("vivid color");
  if (input.saturation === "muted") add("muted color");
  for (const phrase of bigrams(tokens)) add(phrase);

  const category = detectCategory([primary, ...tokens, ...ordered]);
  for (const tail of CATEGORY_TAIL[category] ?? CATEGORY_TAIL.general) add(tail);

  if (input.mode === "vector") {
    for (const term of ["vector illustration", "flat design", "geometric", "solid color", "clean shape", "graphic illustration"]) {
      add(term);
    }
  } else {
    for (const term of ["realistic", "photorealistic", "commercial", "lifestyle photography"]) add(term);
  }

  const modifiers =
    input.mode === "vector"
      ? ["flat", "simple", "geometric", "icon"]
      : ["close up", "detail", "natural", "commercial"];
  const subjects = [primary, ...tokens].slice(0, 6);
  for (const subject of subjects) {
    for (const modifier of modifiers) add(`${modifier} ${subject}`);
    for (const color of input.colors.slice(0, 2)) add(`${color} ${subject}`);
  }

  for (const token of tokens) {
    for (const rel of RELATED[token] ?? []) add(rel);
  }
  for (const tail of CATEGORY_TAIL.general) add(tail);
  for (const extra of [
    "square format",
    "centered subject",
    "clean backdrop",
    "editorial",
    "catalog",
    "advertising",
    "minimal",
    "modern",
    "detail shot",
    "studio setup",
  ]) {
    add(extra);
  }

  const keywords = ordered.slice(0, 40);
  while (keywords.length < 40) {
    const filler = `concept ${keywords.length + 1}`;
    if (seen.has(filler)) break;
    seen.add(filler);
    keywords.push(filler);
  }

  return {
    title: cleanTitle(input.prompt, input.mode, input.colors),
    keywords,
  };
}

export function parseKeywordText(text: string): string[] {
  const seen = new Set<string>();
  const list: string[] = [];
  for (const part of text.split(/[,|\n]/)) {
    const keyword = sanitizeKeyword(part);
    if (!keyword || seen.has(keyword)) continue;
    seen.add(keyword);
    list.push(keyword);
  }
  return list;
}
