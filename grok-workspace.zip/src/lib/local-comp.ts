import type { StockMode } from "@/lib/stock-meta";

function hash(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  let a = seed || 1;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PALETTES = [
  ["#1c1915", "#d84a2f", "#f3efe6", "#e7d7b8", "#6d675e"],
  ["#143028", "#d84a2f", "#f6f1e8", "#efc56b", "#2f6f62"],
  ["#1d2433", "#e7e1d4", "#d84a2f", "#8aa0b8", "#faf7f2"],
  ["#3d2914", "#f0d2a0", "#d84a2f", "#6e8b74", "#f7f1e6"],
];

export function paintLocalComp(prompt: string, mode: StockMode): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = 1024;
  canvas.height = 1024;
  const ctx = canvas.getContext("2d");
  if (!ctx) return canvas;
  const rand = mulberry32(hash(`${mode}:${prompt}`));
  const palette = PALETTES[Math.floor(rand() * PALETTES.length)];

  const gradient = ctx.createLinearGradient(0, 0, 1024, 1024);
  gradient.addColorStop(0, palette[3]);
  gradient.addColorStop(1, palette[1] === "#d84a2f" ? palette[4] : palette[1]);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 1024, 1024);

  if (mode === "vector") {
    ctx.fillStyle = palette[2];
    ctx.beginPath();
    ctx.arc(720, 280, 180, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = palette[0];
    ctx.fillRect(120, 620, 520, 220);
    ctx.fillStyle = palette[1];
    ctx.beginPath();
    ctx.moveTo(180, 620);
    ctx.lineTo(420, 360);
    ctx.lineTo(660, 620);
    ctx.closePath();
    ctx.fill();
    for (let i = 0; i < 5; i++) {
      ctx.fillStyle = palette[i % palette.length];
      const x = 140 + rand() * 740;
      const y = 140 + rand() * 500;
      const s = 70 + rand() * 140;
      ctx.fillRect(x, y, s, s * (0.45 + rand() * 0.5));
    }
    return canvas;
  }

  const glow = ctx.createRadialGradient(360, 280, 40, 420, 360, 640);
  glow.addColorStop(0, "rgba(255,248,236,0.85)");
  glow.addColorStop(1, "rgba(255,248,236,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, 1024, 1024);

  for (let i = 0; i < 14; i++) {
    ctx.fillStyle = palette[i % palette.length];
    ctx.globalAlpha = 0.18 + rand() * 0.28;
    ctx.beginPath();
    ctx.ellipse(rand() * 1024, rand() * 1024, 80 + rand() * 220, 60 + rand() * 180, rand() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.fillStyle = palette[0];
  ctx.globalAlpha = 0.55;
  ctx.fillRect(0, 700, 1024, 324);
  ctx.globalAlpha = 1;
  ctx.fillStyle = palette[2];
  ctx.beginPath();
  ctx.ellipse(512, 760, 220, 70, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = palette[1];
  ctx.beginPath();
  ctx.arc(512, 560, 120, 0, Math.PI * 2);
  ctx.fill();
  return canvas;
}
