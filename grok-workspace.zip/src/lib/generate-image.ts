import { createServerFn } from "@tanstack/react-start";

type Mode = "photo" | "vector";

const MODELS = ["grok-imagine-image", "grok-imagine-image-quality", "grok-imagine-image-2.0"];

function wrapPrompt(prompt: string, mode: Mode): string {
  const subject = prompt.replace(/\s+/g, " ").trim();
  if (mode === "vector") {
    return `Flat vector illustration on a square canvas, solid colors, clean geometric shapes, limited palette, crisp edges, no gradients, no photoreal texture, no text, no letters, no numbers, no watermark, no logo, no signature, no border. Subject: ${subject}`;
  }
  return `Commercial stock photograph, square framing, realistic natural lighting, sharp subject, no text, no letters, no numbers, no watermark, no logo, no signature, no border, no frame. Subject: ${subject}`;
}

async function imageToBase64(payload: { url?: string; b64_json?: string }): Promise<{ base64: string; mime: string }> {
  if (payload.b64_json) {
    return { base64: payload.b64_json, mime: "image/png" };
  }
  if (!payload.url) throw new Error("The image model returned an empty file.");
  const image = await fetch(payload.url);
  if (!image.ok) throw new Error("Could not download the generated image.");
  const mime = image.headers.get("content-type") || "image/png";
  const bytes = new Uint8Array(await image.arrayBuffer());
  if (bytes.byteLength > 12 * 1024 * 1024) throw new Error("Generated image is too large.");
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return { base64: btoa(binary), mime };
}

export const generateStockImage = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    const data = input as { prompt?: unknown; mode?: unknown };
    const prompt = typeof data.prompt === "string" ? data.prompt.trim() : "";
    const mode: Mode = data.mode === "vector" ? "vector" : "photo";
    if (prompt.length < 3 || prompt.length > 500) {
      throw new Error("Describe the image in 3–500 characters.");
    }
    return { prompt, mode };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "Live image generation is not available right now." };
    }

    let lastError = "Image generation failed.";
    for (const model of MODELS) {
      try {
        const res = await fetch("https://api.x.ai/v1/images/generations", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model,
            prompt: wrapPrompt(data.prompt, data.mode),
            n: 1,
            resolution: "1k",
            aspect_ratio: "1:1",
            response_format: "b64_json",
          }),
        });
        if (!res.ok) {
          lastError = `Image model error ${res.status}.`;
          if (res.status === 400 || res.status === 404) continue;
          return { ok: false as const, error: lastError };
        }
        const body = (await res.json()) as {
          data?: Array<{ url?: string; b64_json?: string }>;
        };
        const first = body.data?.[0];
        if (!first) {
          lastError = "The image model returned no file.";
          continue;
        }
        const image = await imageToBase64(first);
        return { ok: true as const, ...image };
      } catch (error) {
        lastError = error instanceof Error ? error.message : lastError;
      }
    }
    return { ok: false as const, error: lastError };
  });
