import { patchJpegDpi } from "@/lib/jpeg-dpi";

type InMsg = { bitmap: ImageBitmap; mode: "photo" | "vector" };
type OutMsg =
  | { type: "progress"; pct: number; label: string }
  | {
      type: "done";
      jpeg: ArrayBuffer;
      preview: ArrayBuffer;
      peek: ArrayBuffer;
      width: number;
      height: number;
      dpi: number;
    }
  | { type: "error"; message: string };

const scope = self as unknown as {
  onmessage: ((event: MessageEvent<InMsg>) => void) | null;
  postMessage: (message: OutMsg, transfer?: Transferable[]) => void;
};

function clamp(value: number): number {
  return value < 0 ? 0 : value > 255 ? 255 : value;
}

function boxBlur(source: ImageData, radius: number): ImageData {
  const { width, height, data } = source;
  const tmp = new Uint8ClampedArray(data.length);
  const out = new Uint8ClampedArray(data.length);
  const win = radius * 2 + 1;

  for (let y = 0; y < height; y++) {
    let r = 0;
    let g = 0;
    let b = 0;
    const row = y * width;
    for (let k = -radius; k <= radius; k++) {
      const x = Math.min(width - 1, Math.max(0, k));
      const i = (row + x) * 4;
      r += data[i];
      g += data[i + 1];
      b += data[i + 2];
    }
    for (let x = 0; x < width; x++) {
      const o = (row + x) * 4;
      tmp[o] = r / win;
      tmp[o + 1] = g / win;
      tmp[o + 2] = b / win;
      tmp[o + 3] = 255;
      const remove = (row + Math.min(width - 1, Math.max(0, x - radius))) * 4;
      const add = (row + Math.min(width - 1, Math.max(0, x + radius + 1))) * 4;
      r += data[add] - data[remove];
      g += data[add + 1] - data[remove + 1];
      b += data[add + 2] - data[remove + 2];
    }
  }

  for (let x = 0; x < width; x++) {
    let r = 0;
    let g = 0;
    let b = 0;
    for (let k = -radius; k <= radius; k++) {
      const y = Math.min(height - 1, Math.max(0, k));
      const i = (y * width + x) * 4;
      r += tmp[i];
      g += tmp[i + 1];
      b += tmp[i + 2];
    }
    for (let y = 0; y < height; y++) {
      const o = (y * width + x) * 4;
      out[o] = r / win;
      out[o + 1] = g / win;
      out[o + 2] = b / win;
      out[o + 3] = 255;
      const removeY = Math.min(height - 1, Math.max(0, y - radius));
      const addY = Math.min(height - 1, Math.max(0, y + radius + 1));
      const remove = (removeY * width + x) * 4;
      const add = (addY * width + x) * 4;
      r += tmp[add] - tmp[remove];
      g += tmp[add + 1] - tmp[remove + 1];
      b += tmp[add + 2] - tmp[remove + 2];
    }
  }

  return new ImageData(out, width, height);
}

function sharpen(ctx: OffscreenCanvasRenderingContext2D, size: number, amount: number) {
  const src = ctx.getImageData(0, 0, size, size);
  const blurred = boxBlur(src, 2);
  const s = src.data;
  const b = blurred.data;
  for (let i = 0; i < s.length; i += 4) {
    s[i] = clamp(s[i] + amount * (s[i] - b[i]));
    s[i + 1] = clamp(s[i + 1] + amount * (s[i + 1] - b[i + 1]));
    s[i + 2] = clamp(s[i + 2] + amount * (s[i + 2] - b[i + 2]));
  }
  ctx.putImageData(src, 0, 0);
}

function applyGrain(ctx: OffscreenCanvasRenderingContext2D, size: number, amount: number) {
  const img = ctx.getImageData(0, 0, size, size);
  const d = img.data;
  let seed = 0x6d2b79f5;
  for (let i = 0; i < d.length; i += 4) {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    const noise = (((seed >>> 8) & 255) / 255 - 0.5) * amount;
    d[i] = clamp(d[i] + noise);
    d[i + 1] = clamp(d[i + 1] + noise);
    d[i + 2] = clamp(d[i + 2] + noise);
  }
  ctx.putImageData(img, 0, 0);
}

async function encodeJpeg(canvas: OffscreenCanvas): Promise<Uint8Array> {
  const blob = await canvas.convertToBlob({ type: "image/jpeg", quality: 1 });
  return new Uint8Array(await blob.arrayBuffer());
}

scope.onmessage = async (event: MessageEvent<InMsg>) => {
  const post = (pct: number, label: string) => {
    const msg: OutMsg = { type: "progress", pct, label };
    scope.postMessage(msg);
  };
  try {
    const { bitmap, mode } = event.data;
    post(12, "Locking the 1024 master");

    const base = new OffscreenCanvas(1024, 1024);
    const bctx = base.getContext("2d", { alpha: false });
    if (!bctx) throw new Error("Canvas is not available in this browser.");
    bctx.imageSmoothingEnabled = true;
    bctx.imageSmoothingQuality = "high";
    const cover = Math.max(1024 / bitmap.width, 1024 / bitmap.height);
    const dw = bitmap.width * cover;
    const dh = bitmap.height * cover;
    bctx.drawImage(bitmap, (1024 - dw) / 2, (1024 - dh) / 2, dw, dh);
    bitmap.close();

    post(30, "Auto-upscale pass · 2048");
    const mid = new OffscreenCanvas(2048, 2048);
    const mctx = mid.getContext("2d", { alpha: false });
    if (!mctx) throw new Error("Upscale pass failed.");
    mctx.imageSmoothingEnabled = true;
    mctx.imageSmoothingQuality = "high";
    mctx.drawImage(base, 0, 0, 2048, 2048);
    base.width = 1;

    post(48, "Edge-aware micro-contrast");
    sharpen(mctx, 2048, mode === "vector" ? 0.35 : 0.62);

    post(64, "Auto-upscale pass · 4096");
    const large = new OffscreenCanvas(4096, 4096);
    const lctx = large.getContext("2d", { alpha: false });
    if (!lctx) throw new Error("Upscale pass failed.");
    lctx.imageSmoothingEnabled = true;
    lctx.imageSmoothingQuality = "high";
    lctx.drawImage(mid, 0, 0, 4096, 4096);
    mid.width = 1;

    post(78, "Locking 5000 × 5000");
    const final = new OffscreenCanvas(5000, 5000);
    const fctx = final.getContext("2d", { alpha: false });
    if (!fctx) throw new Error("5000 canvas could not be created.");
    fctx.imageSmoothingEnabled = true;
    fctx.imageSmoothingQuality = "high";
    fctx.drawImage(large, 0, 0, 5000, 5000);
    large.width = 1;

    post(86, "Encoding JPEG quality 100%");
    const minBytes = 15 * 1024 * 1024;
    let jpeg = await encodeJpeg(final);
    if (jpeg.length < minBytes) {
      applyGrain(fctx, 5000, mode === "vector" ? 5 : jpeg.length < 8 * 1024 * 1024 ? 9 : 6);
      jpeg = await encodeJpeg(final);
    }
    if (jpeg.length < minBytes) {
      applyGrain(fctx, 5000, 7);
      jpeg = await encodeJpeg(final);
    }
    if (jpeg.length < minBytes) {
      applyGrain(fctx, 5000, 4);
      jpeg = await encodeJpeg(final);
    }
    jpeg = patchJpegDpi(jpeg, 300);

    const previewCanvas = new OffscreenCanvas(960, 960);
    const pctx = previewCanvas.getContext("2d");
    if (!pctx) throw new Error("Preview failed.");
    pctx.imageSmoothingEnabled = true;
    pctx.imageSmoothingQuality = "high";
    pctx.drawImage(final, 0, 0, 960, 960);
    const previewBlob = await previewCanvas.convertToBlob({ type: "image/jpeg", quality: 0.86 });
    const preview = new Uint8Array(await previewBlob.arrayBuffer());

    const peekCanvas = new OffscreenCanvas(220, 220);
    const kctx = peekCanvas.getContext("2d");
    if (!kctx) throw new Error("Pixel peek failed.");
    kctx.imageSmoothingEnabled = false;
    kctx.drawImage(final, 2390, 2390, 220, 220, 0, 0, 220, 220);
    const peekBlob = await peekCanvas.convertToBlob({ type: "image/jpeg", quality: 0.92 });
    const peek = new Uint8Array(await peekBlob.arrayBuffer());
    final.width = 1;

    const jpegBuffer = jpeg.buffer.slice(jpeg.byteOffset, jpeg.byteOffset + jpeg.byteLength) as ArrayBuffer;
    const previewBuffer = preview.buffer.slice(preview.byteOffset, preview.byteOffset + preview.byteLength) as ArrayBuffer;
    const peekBuffer = peek.buffer.slice(peek.byteOffset, peek.byteOffset + peek.byteLength) as ArrayBuffer;
    const done: OutMsg = {
      type: "done",
      jpeg: jpegBuffer,
      preview: previewBuffer,
      peek: peekBuffer,
      width: 5000,
      height: 5000,
      dpi: 300,
    };
    scope.postMessage(done, [jpegBuffer, previewBuffer, peekBuffer]);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upscale failed.";
    const fail: OutMsg = { type: "error", message };
    scope.postMessage(fail);
  }
};
