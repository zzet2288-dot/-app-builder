import ImageTracer from "imagetracerjs";
import { traceDataToEps, traceDataToSvg, type TraceData } from "@/lib/eps";

type InMsg = { bitmap: ImageBitmap; title: string };

const scope = self as unknown as {
  onmessage: ((event: MessageEvent<InMsg>) => void) | null;
  postMessage: (message: unknown) => void;
};

scope.onmessage = (event: MessageEvent<InMsg>) => {
  try {
    const size = 480;
    const canvas = new OffscreenCanvas(size, size);
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) throw new Error("Tracer canvas unavailable.");
    const { bitmap, title } = event.data;
    const cover = Math.max(size / bitmap.width, size / bitmap.height);
    const dw = bitmap.width * cover;
    const dh = bitmap.height * cover;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(bitmap, (size - dw) / 2, (size - dh) / 2, dw, dh);
    bitmap.close();
    const image = ctx.getImageData(0, 0, size, size);
    const traced = ImageTracer.imagedataToTracedata(image, {
      ltres: 1,
      qtres: 1,
      pathomit: 8,
      rightangleenhance: true,
      numberofcolors: 16,
      mincolorratio: 0.015,
      colorquantcycles: 3,
      strokewidth: 0,
      linefilter: true,
      scale: 1,
      roundcoords: 1,
      layering: 0,
    }) as TraceData;
    const { eps, paths } = traceDataToEps(traced, title);
    const svg = traceDataToSvg(traced);
    scope.postMessage({ type: "done", eps, svg, paths });
  } catch (error) {
    scope.postMessage({
      type: "error",
      message: error instanceof Error ? error.message : "Vector trace failed.",
    });
  }
};
